<?php ?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>HOJA DE PEDIDO</title>      

    </head>
    <body>   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      


            <div id="temp">  

                <!-- margen superior -->


                <!-- Formulario que almacena todos los datos -->        
                <form method="post" name="form1">

                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <!-- Parte superior del formulario--> 
                                <div class="row">
                                    <div class="col-md-12">                                       
                                        <div class="lineOrangeTitle" style="background-color: black; color: white">
                                            <p class="alignV"> 
                                                HOJA DE PEDIDO 2018
                                            </p>
                                        </div>     
                                        <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                            <p class="alignV"> 
                                                Educamos a través del arte
                                            </p>
                                        </div>
                                        <!--Genera una linea azul--> 
                                        <div class="lineOrange"> </div>

                                        <div class="lineOrangeTitle">
                                            <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                                Por favor haga su pedido. No olvide seleccionar mínimo 25 UNIDADES por tema  
                                            </p>
                                        </div> 
                                        <!--Genera una linea azul--> 
                                        <div class="lineOrange"></div>
                                    </div>

                                </div>
                                
                                
                                
                                
                                <div class="col-sm-12" style="background-color: whitesmoke; padding-top: 5px;"> 
                                    <!-- Se crean 3 tablas diferentes para crear el formulario --> 
                                    <div class="col-sm-4">          
                                        <table class="textI">                
                                            <tr>

                                                <td class="textC negrita" colspan="3"> &nbsp; &nbsp;  LAMINAS: SOLARTE - EDUCARTE  </td>                    

                                            </tr>
                                            <tr>                                            
                                                <td class="textC negrita" colspan="3"> &nbsp; &nbsp;  COD: 7861000152808  </td>                    

                                            </tr>
                                            <tr>                                              
                                                <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS PANAMÁ  </td>                    

                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP1" id="LaminaSP1" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;1 </td>                    
                                                <td> <label for="LaminaSP1">&nbsp; &nbsp;INDIOS GUNAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP2" id="LaminaSP2" value="" min="25" max="9999" step="25"   > </td>                    
                                                <td> &nbsp; &nbsp;2 </td>                    
                                                <td> <label for="LaminaSP2">&nbsp; &nbsp;INDIOS GUAYMÍES</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SP3" id="LaminaSP3" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;3 </td>                    
                                                <td> <label for="LaminaSP3">&nbsp; &nbsp;INDIOS CHOCOES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP4" id="LaminaSP4" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;4 </td>                    
                                                <td> <label for="LaminaSP4">&nbsp; &nbsp;INDIOS TERIBES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP5" id="LaminaSP5" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;5 </td>                    
                                                <td> <label for="LaminaSP5">&nbsp; &nbsp;INDIOS BOKOTAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP6" id="LaminaSP6" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;6 </td>                    
                                                <td> <label for="LaminaSP6">&nbsp; &nbsp;HIS.PAN.ÉPOCA PREHISPANIC.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP7" id="LaminaSP7" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;7 </td>                    
                                                <td> <label for="LaminaSP7">&nbsp; &nbsp;HIS.PAN.DESC.Y CONQUISTA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP8" id="LaminaSP8" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;8 </td>                    
                                                <td> <label for="LaminaSP8">&nbsp; &nbsp;HIS.PAN.ÉPOCA COLONIAL.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP9" id="LaminaSP9" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;9 </td>                    
                                                <td> <label for="LaminaSP9">&nbsp; &nbsp;HIS.PAN.INDEP. G. COLOMBIA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP10" id="LaminaSP10" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;10 </td>                    
                                                <td> <label for="LaminaSP10">&nbsp; &nbsp;HIS.PAN.ÉPOCA REPUBLICANA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP11" id="LaminaSP11" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;11 </td>                    
                                                <td> <label for="LaminaSP11">&nbsp; &nbsp;CANAL DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP12" id="LaminaSP12" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;12 </td>                    
                                                <td> <label for="LaminaSP12">&nbsp; &nbsp;BAILES TÍPICOS PANAMEÑOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP13" id="LaminaSP13" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;13 </td>                    
                                                <td> <label for="LaminaSP13">&nbsp; &nbsp;SÍMBOLOS PATRIOS PANAM.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP14" id="LaminaSP14" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;14 </td>                    
                                                <td> <label for="LaminaSP14">&nbsp; &nbsp;PANAMÁ LA VIEJA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP15" id="LaminaSP15" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;15 </td>                    
                                                <td> <label for="LaminaSP15">&nbsp; &nbsp;TRAJES TÍPICOS PANAMEÑOS</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP16" id="LaminaSP16" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;16 </td>                    
                                                <td> <label for="LaminaSP16">&nbsp; &nbsp;ANIMALES EXTINCIÓN PANA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP17" id="LaminaSP17" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;17 </td>                    
                                                <td> <label for="LaminaSP17">&nbsp; &nbsp;ARTESANÍAS PANAMEÑAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP18" id="LaminaSP18" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;18 </td>                    
                                                <td> <label for="LaminaSP18">&nbsp; &nbsp;PROVINCIA DE PANAMÁ</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP19" id="LaminaSP19" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;19 </td>                    
                                                <td> <label for="LaminaSP19">&nbsp; &nbsp;PROVINCIA DE COLÓN</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP20" id="LaminaSP20" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;20 </td>                    
                                                <td> <label for="LaminaSP20">&nbsp; &nbsp;INST. MUSICALES DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP21" id="LaminaSP21" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;21 </td>                    
                                                <td> <label for="LaminaSP21">&nbsp; &nbsp;PROD.AGRÍC.PANAMEÑOS 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP22" id="LaminaSP22" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;22 </td>                    
                                                <td> <label for="LaminaSP22">&nbsp; &nbsp;PROD.AGRÍC.PANAMEÑOS 2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP23" id="LaminaSP23" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;23 </td>                    
                                                <td> <label for="LaminaSP23">&nbsp; &nbsp;PROVINCIA DE COCLÉ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP24" id="LaminaSP24" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;24 </td>                    
                                                <td> <label for="LaminaSP24">&nbsp; &nbsp;PROVINCIA DE HERRERA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP25" id="LaminaSP25" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;25 </td>                    
                                                <td> <label for="LaminaSP25">&nbsp; &nbsp;PROVINCIA DE LOS SANTOS</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP26" id="LaminaSP26" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;26 </td>                    
                                                <td> <label for="LaminaSP16">&nbsp; &nbsp;PROVINCIA DE VERAGUAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP27" id="LaminaSP27" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;27 </td>                    
                                                <td> <label for="LaminaSP27">&nbsp; &nbsp;PROVINCIA DE CHIRIQUÍ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP28" id="LaminaSP28" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;28 </td>                    
                                                <td> <label for="LaminaSP28">&nbsp; &nbsp;PROVIN.DE BOCAS DELTORO</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP29" id="LaminaSP29" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;29 </td>                    
                                                <td> <label for="LaminaSP29">&nbsp; &nbsp;PROVINCIA DEL DARIÉN</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP30" id="LaminaSP30" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;30 </td>                    
                                                <td> <label for="LaminaSP30">&nbsp; &nbsp;PROVINCIA DE KUNA-YALA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP31" id="LaminaSP31" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;31 </td>                    
                                                <td> <label for="LaminaSP31">&nbsp; &nbsp;COMIDA TÍPICA PANAMEÑA 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP32" id="LaminaSP32" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;32 </td>                    
                                                <td> <label for="LaminaSP32">&nbsp; &nbsp;COMIDA TÍPICA PANAMEÑA 2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP33" id="LaminaSP33" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;33 </td>                    
                                                <td> <label for="LaminaSP33">&nbsp; &nbsp;TIPOS DE VIVIENDA PANAME.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP34" id="LaminaSP34" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;34 </td>                    
                                                <td> <label for="LaminaSP34">&nbsp; &nbsp;PARQUES N. PANAMEÑOS 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP35" id="LaminaSP35" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;35 </td>                    
                                                <td> <label for="LaminaSP35">&nbsp; &nbsp;PARQUES N. PANAMEÑOS 2</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP36" id="LaminaSP36" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;36 </td>                    
                                                <td> <label for="LaminaSP36">&nbsp; &nbsp;GRUPOS ÉTNICOS PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP37" id="LaminaSP37" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;37 </td>                    
                                                <td> <label for="LaminaSP37">&nbsp; &nbsp;PANAMÁ MAPA FÍSICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP38" id="LaminaSP38" value="" min="25" max="9999" step="25"   > </td>                    
                                                <td> &nbsp; &nbsp;38 </td>                    
                                                <td> <label for="LaminaSP38">&nbsp; &nbsp;PANAMÁ MAPA POLÍTICO</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP39" id="LaminaSP39" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;39 </td>                    
                                                <td> <label for="LaminaSP39">&nbsp; &nbsp;PANAMÁ MAPA HIDROGRA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP40" id="LaminaSP40" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;40 </td>                    
                                                <td> <label for="LaminaSP40">&nbsp; &nbsp;DÍA DE LAS MADRES (8-DICI.)</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP41" id="LaminaSP41" value="" min="25" max="9999" step="25"  > </td>                 
                                                <td> &nbsp; &nbsp;41 </td>                    
                                                <td> <label for="LaminaSP41">&nbsp; &nbsp;PRIN.INST.ESTATALES PANA. 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP42" id="LaminaSP42" value="" min="25" max="9999" step="25"  > </td> 
                                                <td> &nbsp; &nbsp;42 </td>                    
                                                <td> <label for="LaminaSP42">&nbsp; &nbsp;PRIN.INST.ESTATALES PANA. 2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP43" id="LaminaSP43" value="" min="25" max="9999" step="25"  > </td>                  
                                                <td> &nbsp; &nbsp;43 </td>                    
                                                <td> <label for="LaminaSP43">&nbsp; &nbsp;PERSONAJES IMPOR.PANA. 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP44" id="LaminaSP44" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;44 </td>                    
                                                <td> <label for="LaminaSP44">&nbsp; &nbsp;PERSONAJES IMPOR.PANA. 2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP45" id="LaminaSP45" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;45 </td>                    
                                                <td> <label for="LaminaSP45">&nbsp; &nbsp;INCIDENTES TAJADA SANDÍA</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP46" id="LaminaSP46" value="" min="25" max="9999" step="25"  > </td>             
                                                <td> &nbsp; &nbsp;46 </td>                    
                                                <td> <label for="LaminaSP46">&nbsp; &nbsp;10-NOV.1821 - GRITO INDEP.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP47" id="LaminaSP47" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;47 </td>                    
                                                <td> <label for="LaminaSP47">&nbsp; &nbsp;28-NOV.1821 - IND.PAN/ESPAÑA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP48" id="LaminaSP48" value="" min="25" max="9999" step="25"  > </td>                
                                                <td> &nbsp; &nbsp;48 </td>                    
                                                <td> <label for="LaminaSP48">&nbsp; &nbsp;3 NOV.1903-SEP/PAN.G COLOM.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP49" id="LaminaSP49" value="" min="25" max="9999" step="25"  > </td>              
                                                <td> &nbsp; &nbsp;49 </td>                    
                                                <td> <label for="LaminaSP49">&nbsp; &nbsp;4 NOV.1903 - PRIN. HECHOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP50" id="LaminaSP50" value="" min="25" max="9999" step="25"  > </td>       
                                                <td> &nbsp; &nbsp;50 </td>                    
                                                <td> <label for="LaminaSP50">&nbsp; &nbsp;5 NOV.1903 - PRIN. HECHOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP51" id="LaminaSP51" value="" min="25" max="9999" step="25"  > </td>     
                                                <td> &nbsp; &nbsp;51 </td>                    
                                                <td> <label for="LaminaSP51">&nbsp; &nbsp;BANDERA REP. DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP52" id="LaminaSP52" value="" min="25" max="9999" step="25"  > </td>              
                                                <td> &nbsp; &nbsp;52 </td>                    
                                                <td> <label for="LaminaSP52">&nbsp; &nbsp;ESCUDO REPU. DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP53" id="LaminaSP53" value="" min="25" max="9999" step="25"  > </td>              
                                                <td> &nbsp; &nbsp;53 </td>                    
                                                <td> <label for="LaminaSP53">&nbsp; &nbsp;HIMNO REPU. DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP54" id="LaminaSP54" value="" min="25" max="9999" step="25"  > </td>                
                                                <td> &nbsp; &nbsp;54 </td>                    
                                                <td> <label for="LaminaSP54">&nbsp; &nbsp;ELEMENTOS.BANDYESC.PAN.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP55" id="LaminaSP55" value="" min="25" max="9999" step="25"  > </td>        
                                                <td> &nbsp; &nbsp;55 </td>                    
                                                <td> <label for="LaminaSP55">&nbsp; &nbsp;USO CORRECTO BAN Y ESC.P.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP56" id="LaminaSP56" value="" min="25" max="9999" step="25"  > </td>       
                                                <td> &nbsp; &nbsp;56 </td>                    
                                                <td> <label for="LaminaSP56">&nbsp; &nbsp;CULT.PRECOLOMBINAS PAN.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP57" id="LaminaSP57" value="" min="25" max="9999" step="25"  > </td>             
                                                <td> &nbsp; &nbsp;57 </td>                    
                                                <td> <label for="LaminaSP57">&nbsp; &nbsp;ARTE PRECOLOM.CERÁMICA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP58" id="LaminaSP58" value="" min="25" max="9999" step="25"  > </td>                  
                                                <td> &nbsp; &nbsp;58 </td>                    
                                                <td> <label for="LaminaSP58">&nbsp; &nbsp;ARTE PRECOLOM.ORFEBRE.</label> </td>



                                        </table>

                                    </div>

                                    <div class="col-sm-4">             

                                        <table  class="textI">                                    
                                            <tr>
                                                <td> <input  type="number" name="SP59" id="LaminaSP59" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;59 </td>                    
                                                <td> <label for="LaminaSP59">&nbsp; &nbsp;ARTE PRECOLOM.ESCULTUR.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP60" id="LaminaSP60" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;60 </td>                    
                                                <td> <label for="LaminaSP60">&nbsp; &nbsp;LA ETNIA NEGRA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP61" id="LaminaSP61" value="" min="25" max="9999" step="25"  > </td>                     
                                                <td> &nbsp; &nbsp;61 </td>                    
                                                <td> <label for="LaminaSP61">&nbsp; &nbsp;GOBERNANTES DE REP. PAN. 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP62" id="LaminaSP62" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;62 </td>                    
                                                <td> <label for="LaminaSP24">&nbsp; &nbsp;GOBERNANTES DE REP. PAN. 2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP63" id="LaminaSP63" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;63 </td>                    
                                                <td> <label for="LaminaSP63">&nbsp; &nbsp;CENTRALES HIDROELÉC. PAN.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP64" id="LaminaSP64" value="" min="25" max="9999" step="25"  > </td>                  
                                                <td> &nbsp; &nbsp;64 </td>                    
                                                <td> <label for="LaminaSP64">&nbsp; &nbsp;PROD. AGRIC. TIERRAS BAJAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP65" id="LaminaSP65" value="" min="25" max="9999" step="25"  > </td>            
                                                <td> &nbsp; &nbsp;65 </td>                    
                                                <td> <label for="LaminaSP65">&nbsp; &nbsp;PROD. AGRIC. TIERRAS ALTAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP66" id="LaminaSP66" value="" min="25" max="9999" step="25"  > </td>                     
                                                <td> &nbsp; &nbsp;66 </td>                    
                                                <td> <label for="LaminaSP66">&nbsp; &nbsp;EL ÁGUILA ARPÍA AVE NACION.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP67" id="LaminaSP67" value="" min="25" max="9999" step="25"  > </td>             
                                                <td> &nbsp; &nbsp;67 </td>                    
                                                <td> <label for="LaminaSP67">&nbsp; &nbsp;PAN.VIEJA MONU. HISTORICOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP68" id="LaminaSP68" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;68 </td>                    
                                                <td> <label for="LaminaSP68">&nbsp; &nbsp;FLOR DEL ESPÍRITU SANTO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP69" id="LaminaSP69" value="" min="25" max="9999" step="25"  > </td>              
                                                <td> &nbsp; &nbsp;69 </td>                    
                                                <td> <label for="LaminaSP69">&nbsp; &nbsp;GUERRA DE LOS MIL DIAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP70" id="LaminaSP70" value="" min="25" max="9999" step="25"  > </td>          
                                                <td> &nbsp; &nbsp;70 </td>                    
                                                <td> <label for="LaminaSP70">&nbsp; &nbsp;CELEBR.Y FIESTAS PATRIAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP71" id="LaminaSP71" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;71 </td>                    
                                                <td> <label for="LaminaSP71">&nbsp; &nbsp;POEMAS A LA PATRIA DE PANA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP72" id="LaminaSP72" value="" min="25" max="9999" step="25"  > </td>                 
                                                <td> &nbsp; &nbsp;72 </td>                    
                                                <td> <label for="LaminaSP72">&nbsp; &nbsp;CANCIONES A LA PATRIA PANA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP73" id="LaminaSP73" value="" min="25" max="9999" step="25"  > </td>              
                                                <td> &nbsp; &nbsp;73 </td>                    
                                                <td> <label for="LaminaSP73">&nbsp; &nbsp;POEMAS A LA MADRE DE PANA.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP74" id="LaminaSP74" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;74 </td>                    
                                                <td> <label for="LaminaSP74">&nbsp; &nbsp;EL BALBOA Y SUS FRACCIONES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP75" id="LaminaSP75" value="" min="25" max="9999" step="25"  > </td>                
                                                <td> &nbsp; &nbsp;75 </td>                    
                                                <td> <label for="LaminaSP75">&nbsp; &nbsp;PRINCIP. PTOS. DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP76" id="LaminaSP76" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;76 </td>                    
                                                <td> <label for="LaminaSP76">&nbsp; &nbsp;PUENT.AMÉRICAS,CENTENA.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP77" id="LaminaSP77" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;77</td>                    
                                                <td> <label for="LaminaSP77">&nbsp; &nbsp;PRIN.LUGARES TUR.PANA.1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP78" id="LaminaSP78" value="" min="25" max="9999" step="25"  > </td>                     
                                                <td> &nbsp; &nbsp;78 </td>                    
                                                <td> <label for="LaminaSP78">&nbsp; &nbsp;PRIN.LUGARES TUR.PANA.2</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP79" id="LaminaSP79" value="" min="25" max="9999" step="25"  > </td>                     
                                                <td> &nbsp; &nbsp;79 </td>                    
                                                <td> <label for="LaminaSP79">&nbsp; &nbsp;PROVIN. DE PANAMÁ OESTE.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP80" id="LaminaSP80" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;80 </td>                    
                                                <td> <label for="LaminaSP80">&nbsp; &nbsp;EL DOLAR ESTADOUNIDEN.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP81" id="LaminaSP81" value=""min="25" max="9999" step="25"   > </td>                    
                                                <td> &nbsp; &nbsp;81 </td>                    
                                                <td> <label for="LaminaSP81">&nbsp; &nbsp;INDIOS GUNAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP82" id="LaminaSP82" value=""  min="25" max="9999" step="25" > </td>                    
                                                <td> &nbsp; &nbsp;82 </td>                    
                                                <td> <label for="LaminaSP82">&nbsp; &nbsp;AEROPUERTOS DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP83" id="LaminaSP83" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;83 </td>                    
                                                <td> <label for="LaminaSP83">&nbsp; &nbsp;AMPLIA.Y FUNCIO.CANAL PAN.</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP84" id="LaminaSP84" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;84 </td>                    
                                                <td> <label for="LaminaSP84">&nbsp; &nbsp;TIPOS JARDINES - COMERCIAL</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP85" id="LaminaSP85" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;85 </td>                    
                                                <td> <label for="LaminaSP85">&nbsp; &nbsp;TIPOS JARDIN. - ORNAMENTAL</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP86" id="LaminaSP86" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;86 </td>                    
                                                <td> <label for="LaminaSP86">&nbsp; &nbsp;TIPOS JARDINES - MEDICINAL</label> </td>
                                            </tr> <tr>
                                                <td> <input  type="number" name="SP87" id="LaminaSP87" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;87</td>                    
                                                <td> <label for="LaminaSP87">&nbsp; &nbsp;FAUNA Y FLORA DE PANAMÁ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SP88" id="LaminaSP88" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;88 </td>                    
                                                <td> <label for="LaminaSP88">&nbsp; &nbsp;BAILES DANZAS ETNIA PANA.</label> </td>
                                            </tr> 
                                            <tr>
                                                <td> <input  type="number" name="SP89" id="LaminaSP89" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;89 </td>                    
                                                <td> <label for="LaminaSP89">&nbsp; &nbsp;El CIVISMO</label> </td>
                                            </tr> 

                                            <tr>                                                              
                                                <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG1" id="LaminaSG1" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;1 </td>                    
                                                <td> <label for="LaminaSG1">&nbsp; &nbsp;CULTURA AZTECA</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG2" id="LaminaSG2" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;2 </td>                    
                                                <td> <label for="LaminaSG2">&nbsp; &nbsp;CULTURA INCA</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG3" id="LaminaSG3" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;3 </td>                    
                                                <td> <label for="LaminaSG3">&nbsp; &nbsp;CULTURA MAYA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG4" id="LaminaSG4" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;4 </td>                    
                                                <td> <label for="LaminaSG4">&nbsp; &nbsp;CULTURA EGIPCIA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG5" id="LaminaSG5" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;5 </td>                    
                                                <td> <label for="LaminaSG5">&nbsp; &nbsp;CRIPTÓGAMAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG6" id="LaminaSG6" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;6 </td>                    
                                                <td> <label for="LaminaSG6">&nbsp; &nbsp;FANERÓGAMAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG7" id="LaminaSG7" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;7 </td>                    
                                                <td> <label for="LaminaSG7">&nbsp; &nbsp;MEDICINALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG8" id="LaminaSG8" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;8 </td>                    
                                                <td> <label for="LaminaSG8">&nbsp; &nbsp;INDUSTRIALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG9" id="LaminaSG9" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;9 </td>                    
                                                <td> <label for="LaminaSG9">&nbsp; &nbsp;ANIMALES SALVAJES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG10" id="LaminaS10" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;10 </td>                    
                                                <td> <label for="LaminaSG10">&nbsp; &nbsp;ANIMALES DOMÉSTICOS 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG11" id="LaminaSG11" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;11 </td>                    
                                                <td> <label for="LaminaSG11">&nbsp; &nbsp;ANIMALES VERTEBRADOS</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG12" id="LaminaSG12" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;12 </td>                    
                                                <td> <label for="LaminaSG12">&nbsp; &nbsp;ANIMALES INVERTEBRADOS</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG13" id="LaminaSG13" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;13 </td>                    
                                                <td> <label for="LaminaSG13">&nbsp; &nbsp;MOVI. DE TRASLACIÓN</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG14" id="LaminaSG14" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;14 </td>                    
                                                <td> <label for="LaminaSG14">&nbsp; &nbsp;MOVI.ROTACIÓN Y NUTACIÓN</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG15" id="LaminaSG15" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;15 </td>                    
                                                <td> <label for="LaminaSG15">&nbsp; &nbsp;MEDIOS DE TRANSPORTE</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG16" id="LaminaSG16" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;16 </td>                    
                                                <td> <label for="LaminaSG16">&nbsp; &nbsp;LA FAMILIA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG17" id="LaminaSG17" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;17 </td>                    
                                                <td> <label for="LaminaSG17">&nbsp; &nbsp;VIDA DE JESÚS - NIÑEZ</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG18" id="LaminaSG18" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;18 </td>                    
                                                <td> <label for="LaminaSG18">&nbsp; &nbsp;VIDA DE JESÚS - MILAGROS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG19" id="LaminaSG19" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;19 </td>                    
                                                <td> <label for="LaminaSG19">&nbsp; &nbsp;VIDA DE JESÚS - PASIÓN</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG20" id="LaminaS20" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;20 </td>                    
                                                <td> <label for="LaminaSG20">&nbsp; &nbsp;VIDA DE JESÚS - MUERTE</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG21" id="LaminaSG21" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;21 </td>                    
                                                <td> <label for="LaminaSG21">&nbsp; &nbsp;LAS COMUNICACIONES</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG22" id="LaminaSG22" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;22 </td>                    
                                                <td> <label for="LaminaSG22">&nbsp; &nbsp;EL SUELO</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG23" id="LaminaSG23" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;23 </td>                    
                                                <td> <label for="LaminaSG3">&nbsp; &nbsp;EL AGUA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG24" id="LaminaSG24" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;24 </td>                    
                                                <td> <label for="LaminaSG24">&nbsp; &nbsp;EL AIRE</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG25" id="LaminaSG25" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;25 </td>                    
                                                <td> <label for="LaminaSG25">&nbsp; &nbsp;LAS AVES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG26" id="LaminaSG26" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;26 </td>                    
                                                <td> <label for="LaminaSG26">&nbsp; &nbsp;LOS CEREALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG27" id="LaminaSG27" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;27 </td>                    
                                                <td> <label for="LaminaSG27">&nbsp; &nbsp;LOS PECES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG28" id="LaminaSG28" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;28 </td>                    
                                                <td> <label for="LaminaSG28">&nbsp; &nbsp;ANFIBIOS Y REPTILES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG29" id="LaminaSG29" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;29 </td>                    
                                                <td> <label for="LaminaSG29">&nbsp; &nbsp;SISTEMA DIGESTIVO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG30" id="LaminaSG30" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;30 </td>                    
                                                <td> <label for="LaminaSG30">&nbsp; &nbsp;STEMA CIRCULATORIO</label> </td>
                                            </tr>









                                        </table>
                                    </div>
                                    <div class="col-sm-4">           

                                        <table class="textI">

                                            <tr>
                                                <td> <input  type="number" name="SG31" id="LaminaSG31" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;31 </td>                   
                                                <td> <label for="LaminaSG31">&nbsp; &nbsp;SISTEMA RESPIRATORIO</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG32" id="LaminaSG32" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;32 </td>                    
                                                <td> <label for="LaminaSG32">&nbsp; &nbsp;SISTEMA ÓSEO</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG33" id="LaminaSG33" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;33 </td>                    
                                                <td> <label for="LaminaSG33">&nbsp; &nbsp;SISTEMA MUSCULAR</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG34" id="LaminaSG34" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;34 </td>                    
                                                <td> <label for="LaminaSG34">&nbsp; &nbsp;LOS CINCO SENTIDOS 1</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG35" id="LaminaSG35" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;35 </td>                    
                                                <td> <label for="LaminaSG35">&nbsp; &nbsp;LAS PROFESIONES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG36" id="LaminaSG36" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;36 </td>                    
                                                <td> <label for="LaminaSG36">&nbsp; &nbsp;LOS OFICIOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG37" id="LaminaSG37" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;37 </td>                    
                                                <td> <label for="LaminaSG37">&nbsp; &nbsp;LAS FRUTAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG38" id="LaminaSG38" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;38 </td>                    
                                                <td> <label for="LaminaSG38">&nbsp; &nbsp;LAS HORTALIZAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG39" id="LaminaSG39" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;39 </td>                    
                                                <td> <label for="LaminaSG39">&nbsp; &nbsp;LAS LEGUMBRES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG40" id="LaminaS40" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;40 </td>                    
                                                <td> <label for="LaminaSG40">&nbsp; &nbsp;EL CUERPO HUMANO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG41" id="LaminaSG41" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;41 </td>                    
                                                <td> <label for="LaminaSG41">&nbsp; &nbsp;ALIMENTOS Y VITAMINAS</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG42" id="LaminaSG42" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;42 </td>                    
                                                <td> <label for="LaminaSG42">&nbsp; &nbsp;LA RAÍZ</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG43" id="LaminaSG43" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;43 </td>                    
                                                <td> <label for="LaminaSG43">&nbsp; &nbsp;EL BOTIQUIN Y SU USO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG44" id="LaminaSG44" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;44 </td>                    
                                                <td> <label for="LaminaSG44">&nbsp; &nbsp;EL COSTURERO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG45" id="LaminaSG45" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;45 </td>                    
                                                <td> <label for="LaminaSG45">&nbsp; &nbsp;EL ARREGLO DE MESAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG46" id="LaminaSG46" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;46 </td>                    
                                                <td> <label for="LaminaSG46">&nbsp; &nbsp;BUENOS MODALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG7" id="LaminaSG47" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;47 </td>                    
                                                <td> <label for="LaminaSG47">&nbsp; &nbsp;HERRAMIENTAS AGRÍCOLAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG48" id="LaminaSG8" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;48 </td>                    
                                                <td> <label for="LaminaSG48">&nbsp; &nbsp;MAQUINARIA AGRÍCOLA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG49" id="LaminaSG49" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;49 </td>                    
                                                <td> <label for="LaminaSG49">&nbsp; &nbsp;DESCUBRI. DE AMÉRICA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG50" id="LaminaSG50" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;50 </td>                    
                                                <td> <label for="LaminaSG50">&nbsp; &nbsp;LAS ENFERMEDADES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG51" id="LaminaSG51" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;51 </td>                    
                                                <td> <label for="LaminaSG52">&nbsp; &nbsp;HIGIENE ESCOLAR</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG52" id="LaminaSG52" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;52 </td>                    
                                                <td> <label for="LaminaSG52">&nbsp; &nbsp;LA SEXUALIDAD</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG53" id="LaminaSG53" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;53 </td>                    
                                                <td> <label for="LaminaSG53">&nbsp; &nbsp;LOS SERVICIOS PÚBLICOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG54" id="LaminaSG54" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;54 </td>                    
                                                <td> <label for="LaminaSG54">&nbsp; &nbsp;AMÉRICA DEL SUR FÍSICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG55" id="LaminaSG55" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;55 </td>                    
                                                <td> <label for="LaminaSG5">&nbsp; &nbsp;AMÉRICA DEL SUR POLÍTICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG56" id="LaminaSG56" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;56 </td>                    
                                                <td> <label for="LaminaSG56">&nbsp; &nbsp;AMÉRICA DEL NORTE FÍSICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG57" id="LaminaSG57" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;57 </td>                    
                                                <td> <label for="LaminaSG57">&nbsp; &nbsp;AMÉRICA DEL NORTE POLÍTI.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG58" id="LaminaSG58" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;58 </td>                    
                                                <td> <label for="LaminaSG58">&nbsp; &nbsp;EUROPA FÍSICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG59" id="LaminaSG59" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;59 </td>                    
                                                <td> <label for="LaminaSG59">&nbsp; &nbsp;EUROPA POLÍTICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG60" id="LaminaSG60" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;60 </td>                    
                                                <td> <label for="LaminaSG60">&nbsp; &nbsp;ASIA FÍSICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG61" id="LaminaSG61" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;61 </td>                    
                                                <td> <label for="LaminaSG61">&nbsp; &nbsp;ASIA POLÍTICO</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG62" id="LaminaSG62" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;62 </td>                    
                                                <td> <label for="LaminaSG62">&nbsp; &nbsp;ÁFRICA FÍSICO</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG63" id="LaminaSG63" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;63 </td>                    
                                                <td> <label for="LaminaSG63">&nbsp; &nbsp;ÁFRICA POLÍTICO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG64" id="LaminaSG64" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;64 </td>                    
                                                <td> <label for="LaminaSG64">&nbsp; &nbsp;COMPONEN. COMPUTADORA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG65" id="LaminaSG65" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;65 </td>                    
                                                <td> <label for="LaminaSG65">&nbsp; &nbsp;LOS INSECTOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG66" id="LaminaSG66" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;66 </td>                    
                                                <td> <label for="LaminaSG66">&nbsp; &nbsp;LOS CRUSTÁCEOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG67" id="LaminaSG67" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;67 </td>                    
                                                <td> <label for="LaminaSG7">&nbsp; &nbsp;LOS MAMÍFEROS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG68" id="LaminaSG68" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;68 </td>                    
                                                <td> <label for="LaminaSG68">&nbsp; &nbsp;LOS ARÁCNIDOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG69" id="LaminaSG69" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;69 </td>                    
                                                <td> <label for="LaminaSG69">&nbsp; &nbsp;LA CASA Y SUS DEPENDEN.</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG70" id="LaminaS70" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;70 </td>                    
                                                <td> <label for="LaminaSG70">&nbsp; &nbsp;ARTÍC.Y UTENS.DEL HOGAR</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG71" id="LaminaSG71" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;71 </td>                    
                                                <td> <label for="LaminaSG71">&nbsp; &nbsp;ANIMALES ÚTILES</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG72" id="LaminaSG72" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;72 </td>                    
                                                <td> <label for="LaminaSG72">&nbsp; &nbsp;ANIMALES PERJUDICIALES</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG73" id="LaminaSG73" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;73 </td>                    
                                                <td> <label for="LaminaSG73">&nbsp; &nbsp;PLANTAS ORNAMENTALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG74" id="LaminaSG74" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;74 </td>                    
                                                <td> <label for="LaminaSG74">&nbsp; &nbsp;EL SISTEMA SOLAR</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG75" id="LaminaSG75" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;75 </td>                    
                                                <td> <label for="LaminaSG75">&nbsp; &nbsp;EL TALLO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG76" id="LaminaSG76" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;76 </td>                    
                                                <td> <label for="LaminaSG76">&nbsp; &nbsp;LA HOJA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG77" id="LaminaSG77" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;77 </td>                    
                                                <td> <label for="LaminaSG77">&nbsp; &nbsp;LAS ANGIOSPERMAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG78" id="LaminaSG78" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;78 </td>                    
                                                <td> <label for="LaminaSG78">&nbsp; &nbsp;LAS GIMNOSPERMAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG79" id="LaminaSG79" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;79 </td>                    
                                                <td> <label for="LaminaSG79">&nbsp; &nbsp;AMÉRICA FÍSICA COMPLETA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG80" id="LaminaS80" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;80 </td>                    
                                                <td> <label for="LaminaSG80">&nbsp; &nbsp;AMÉRICA POLÍTICA COMPETA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG81" id="LaminaSG81" value="" min="25" max="9999" step="25"  > </td>                   
                                                <td> &nbsp; &nbsp;81 </td>                    
                                                <td> <label for="LaminaSG81">&nbsp; &nbsp;EL APARATO URINARIO</label> </td>
                                            </tr>
                                            <tr> 
                                                <td> <input  type="number" name="SG82" id="LaminaSG82" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;82 </td>                    
                                                <td> <label for="LaminaSG82">&nbsp; &nbsp;EL SISTEMA NERVIOSO</label> </td>
                                            </tr>                                       
                                            <tr>
                                                <td> <input  type="number" name="SG83" id="LaminaSG83" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;83 </td>                    
                                                <td> <label for="LaminaSG83">&nbsp; &nbsp;EL SISTEMA NERVIOSO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG84" id="LaminaSG84" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;84 </td>                    
                                                <td> <label for="LaminaSG84">&nbsp; &nbsp;HERRAMIEN. DE CARPINTERÍA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG85" id="LaminaSG85" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;85 </td>                    
                                                <td> <label for="LaminaSG85">&nbsp; &nbsp;LAS ROCAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG86" id="LaminaSG86" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;86 </td>                    
                                                <td> <label for="LaminaSG86">&nbsp; &nbsp;LOS MINERALES</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG7" id="LaminaSG87" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;87 </td>                    
                                                <td> <label for="LaminaSG87">&nbsp; &nbsp;CICLO VITAL - SERES VIVOS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG88" id="LaminaSG88" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;88 </td>                    
                                                <td> <label for="LaminaSG88">&nbsp; &nbsp;EVOLUCIÓN DE LA VIVIENDA</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG89" id="LaminaSG89" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;89 </td>                    
                                                <td> <label for="LaminaSG89">&nbsp; &nbsp;EL UNIVERSO</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG90" id="LaminaS90" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;90 </td>                    
                                                <td> <label for="LaminaSG90">&nbsp; &nbsp;LAS DROGAS</label> </td>
                                            </tr>
                                            <tr>
                                                <td> <input  type="number" name="SG91" id="LaminaS91" value="" min="25" max="9999" step="25"  > </td>                    
                                                <td> &nbsp; &nbsp;91 </td>                    
                                                <td> <label for="LaminaSG91">&nbsp; &nbsp;MATERIA. DE CONSTRUCCIÓN</label> </td>
                                            </tr>
                                        </table>
                                    </div>

                                </div>









                            </div>

                        </div>          

                </form>

                <div id="valor"></div>






            </div>

    </body>

</html>