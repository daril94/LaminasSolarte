<?php

//session_start();
$_SESSION['Laminas'] = 0;
$_SESSION['Croquis'] = 0;
$_SESSION['TablaElementos'] = 0;
$_SESSION['Cartilla4Operaciones'] = 0;
$_SESSION['LaminasArmables'] = 0;
$_SESSION['CartelesGrandes'] = 0;
$_SESSION['CartelesMedianos'] = 0;
$_SESSION['LibrosColorear'] = 0;

function sumatoria() {


    foreach ($_SESSION['formularioHojas'] as $campo => $a) {
        if ($a > 0 && $a < 10000) {

            if ($campo[0] == 'S' || $campo[0] == 'E') {
                $_SESSION['Laminas'] += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'Q') {
                $_SESSION['Croquis'] += $a;
            } else if ($campo[0] == 'T' && $campo[1] == 'P') {
                $_SESSION['TablaElementos'] += $a;
            }  else if ($campo[0] == 'C' && $campo[1] == 'B') {
                $_SESSION['Cartilla4Operaciones'] += $a;
            } else if ($campo[0] == 'A' ) {
                $_SESSION['LaminasArmables'] += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'G') {
                $_SESSION['CartelesGrandes'] += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'M') {
                $_SESSION['CartelesMedianos'] += $a;
            } else if ($campo[0] == 'L' && $campo[1] == 'C') {
                $_SESSION['LibrosColorear'] += $a;
            }
        }
    }


    $_SESSION['Sumatoria'] = $_SESSION['Laminas'] + $_SESSION['Casas'] + $_SESSION['TablaElementos'] + $_SESSION['Cartilla4Operaciones'] +
            $_SESSION['MapasFullColor'] + $_SESSION['CroquisA4'] + $_SESSION['LibrosColorear'] + $_SESSION['CuerposSueltos'] +
            $_SESSION['BilletesMonedas'] + $_SESSION['Libro28FG'] + $_SESSION['MuestrasSueli'] + $_SESSION['Cucas'] +
            $_SESSION['Afiches'] + $_SESSION['Sumatoria'];
}
