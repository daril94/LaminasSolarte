<?PHP

session_start();
require_once 'mostrarDatos.php';

$provincia = $_SESSION['Vendedor'];

ob_start();
mostrarDatos(1);
$count = 0;
$datos = ob_get_contents();
$data = explode(";", $datos);
//$data = str_replace("G", "", $dat, $contador);
natsort($data);
date_default_timezone_set("America/Bogota");
$fechaActual = date('d-m-Y');
$horaActual = date('H:i:s');
$pedidoW = $_SESSION['Pedido'];
$nombreW = utf8_decode($_SESSION['Nombre']);
$emailW = isset($_SESSION['Email']) ? $_SESSION['Email'] : "";
$telefonoW = $_SESSION['Telefono'];
$direccionW = utf8_decode($_SESSION['Direccion']);
$ccW = $_SESSION['CcRuc'];
$sectorW = utf8_decode($_SESSION['Sector']);



ob_end_clean();


/* En los encabezados indicamos que se trata de un documento de MS-WORD
  y en el nombre de archivo le ponemos la extensión RTF. */


/*  Comenzamos a armar el documento  */
$output = "{\\rtf1";   //<-- Iniciamos un documento RTF

$output .= "{\\fs24 \\b NUMERO DEL PEDIDO        \\b0 $pedidoW   }";
$output .= "\\par ";  //<-- ENTER
$output .= "\\par ";  //<-- ENTER
$output .= "{\\fs24 \\b Fecha        \\b0  $fechaActual}";
$output .= "\\par ";  //<-- ENTER
$output .= "{\\fs24 \\b Hora        \\b0  $horaActual}";
$output .= "\\par ";  //<-- ENTER 
$output .= "\\par ";  //<-- ENTER 
$output .= "{\\fs24 \\b DATOS DEL COMPRADOR  }";
$output .= "\\par ";  //<-- ENTER  
$output .= "\\par ";  //<-- ENTER 
$output .= "{\\fs24 \\b Nombre             \\b0      $nombreW}";
$output .= "\\par ";  //<-- ENTER    
$output .= "{\\fs24 \\b Telefono            \\b0      $telefonoW}";
$output .= "\\par ";  //<-- ENTER   
$output .= "{\\fs24 \\b Direccion            \\b0    $direccionW}";
$output .= "\\par ";  //<-- ENTER   
$output .= "{\\fs24 \\b CI-RUC               \\b0   $ccW}";
$output .= "\\par ";  //<-- ENTER   
$output .= "\\par ";  //<-- ENTER   
$output .= "\\par ";  //<-- ENTER   

$output .= "{\\fs24 \\b TOTAL DEL PEDIDO   }";
$output .= "\\par ";  //<-- ENTER 
if ($_SESSION['Laminas'] > 0) {
    $output .= "{\\fs24 \\b Laminas   \\b0   $_SESSION[Laminas]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['Croquis'] > 0) {
    $output .= "{\\fs24 \\b Croquis   \\b0   $_SESSION[Croquis]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['TablaElementos'] > 0) {
    $output .= "{\\fs24 \\b Tabla de elementos  \\b0   $_SESSION[TablaElementos]}";
    $output .= "\\par ";  //<-- ENTER 
}if ($_SESSION['Cartilla4Operaciones'] > 0) {
    $output .= "{\\fs24 \\b Cartilla 4 operaciones  \\b0   $_SESSION[Cartilla4Operaciones]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['LaminasArmables'] > 0) {
    $output .= "{\\fs24 \\b Laminas Armables   \\b0   $_SESSION[LaminasArmables]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['CartelesGrandes'] > 0) {
    $output .= "{\\fs24 \\b Carteles grandes  \\b0   $_SESSION[CartelesGrandes]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['CartelesMedianos'] > 0) {
    $output .= "{\\fs24 \\b Carteles Medianos   \\b0   $_SESSION[CartelesMedianos]}";
    $output .= "\\par ";  //<-- ENTER 
}
if ($_SESSION['LibrosColorear'] > 0) {
    $output .= "{\\fs24 \\b Libros colorear   \\b0   $_SESSION[LibrosColorear]}";
    $output .= "\\par ";  //<-- ENTER 
}


$output .= "\\par ";  //<-- ENTER 
$output .= "{\\fs24 \\b PEDIDO REALIZADOO   }";
$output .= "\\par ";  //<-- ENTER
foreach ($data as $ds) {
    $count++;
    $output .= "{\\fs24 $ds   }";
    $output .= "\\par ";  //<-- ENTER ;
//echo $count;    
    /* if ($count % 4 == 0) {
      $output .= "\\par ";  //<-- ENTER ;
      } */
}






$output .= "}"; //<-- Terminador del RTF

/*  Enviamos el documento completo a la salida  */
file_put_contents("../wordGenerado/pedido$pedidoW.doc", $output);


require_once 'pdfMail.php';
