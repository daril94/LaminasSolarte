<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hoja de Pedidos 2017-2018</title>
        <style>
            input[type=number]::-webkit-inner-spin-button, 
            input[type=number]::-webkit-outer-spin-button { 
                -webkit-appearance: none; 
                margin: 0; 
            }

            input[type=number] { -moz-appearance:textfield; }
        </style>

    </head>

    <body>   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      


            <!-- Formulario que almacena todos los datos -->        
            <form method="POST" <?php echo "action='?paso=2&hoja=1'" ?>>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018 
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineOrange "> </div>


                                    <div  style="font-size:13px; background-color: whitesmoke; color: #929497; padding:30px" >  
                                        <table class="tablePasos" id="tabla" style="margin: 0 auto; text-align: center; border-collapse: separate;">
                                            <tr class="tdNegro">
                                                <td align="center"> <label for="nombre">Nombre y Apellido</label> </td>                    
                                                <td>&nbsp;&nbsp; </td>
                                                <td align="center"> <label for="email">E-mail</label> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="telefono">Teléfono</label> </td>
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="direccion">Dirección</label> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="ccRuc">CC/RUC</label> </td>
                                            </tr>  
                                            <tr>
                                                <td align="center"> <input  type="text" name="Nombre" id="nombre" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="text" name="Email" id="email" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="number" name="Telefono" id="telefono" value="" min="" required  > </td>
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="text" name="Direccion" id="direccion" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="number" name="CcRuc" id="ccRuc" value="" min="" required > </td>
                                            </tr>  


                                        </table> 
                                    </div>
                                    <div class="lineOrange"></div>
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV">
                                            TIPO DE PEDIDO 
                                        </p>    
                                    </div>
                                    <div class="lineOrange"></div>


                                    <div  style="font-size:13px; background-color: whitesmoke; color: black; padding-top: 10px; padding-bottom: 10px">    
                                        <table style="margin: 0 auto;">
                                            <tr>
                                                <td align="center"> <label for="almacen">Almacen</label> </td>                    
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label for="domicilio">Domicilio</label> </td>                  
                                            </tr>  
                                            <tr>
                                                <td align="center"> <input  type="radio" name="Entrega" id="almacen" value="Almacen" required  > </td>                    
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <input  type="radio" name="Entrega" id="domicilio" value="Domicilio"  > </td> 
                                            </tr>  

                                        </table>  
                                    </div>

                                </div>
                                <div style="padding-top: 50px;"></div>
                                <input type="submit" value="Seguir al Paso 2"  id="send">
                            </div>

                        </div>

                    </div>

                </div>








        </div>

    </form>
</div>
</body>
</html>
