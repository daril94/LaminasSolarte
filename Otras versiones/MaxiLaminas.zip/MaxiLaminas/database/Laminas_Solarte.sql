CREATE DATABASE MaxiLaminas ;
USE MaxiLaminas ;
#drop database MaxiLaminas;

CREATE TABLE IF NOT EXISTS Administrador (
  userAdmin varchar(30) NOT NULL,
  passAdmin text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;

INSERT INTO Administrador (userAdmin, passAdmin) VALUES
('daril_1994@hotmail.com', '12345678');


Create Table Pedido (
pedidoID int not null auto_increment,
constraint pk_pedido Primary Key (pedidoID),
fechaPedido timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
nombreUsuario VARCHAR(50) NOT NULL,
emailUsuario VARCHAR(50) NOT NULL,
direccionUsuario VARCHAR(50) NOT NULL,
telefonoUsuario int  NOT NULL,
ccRucUsuario int  NOT NULL,
entregaUsuario VARCHAR(50) NOT NULL,
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


Create Table laminasPedido (
pedidoID int not null,
CONSTRAINT fk_la FOREIGN KEY (pedidoID)
REFERENCES Pedido (pedidoID)
ON DELETE CASCADE ON UPDATE CASCADE,
codigo VARCHAR(50) NOT NULL,
cantidad int  NOT NULL
)ENGINE=InnoDB  DEFAULT CHARSET=utf8;

Create Table sumatorioPedido (
pedidoID int not null,
CONSTRAINT fk_su FOREIGN KEY (pedidoID)
REFERENCES Pedido (pedidoID)
ON DELETE CASCADE ON UPDATE CASCADE,
nombre VARCHAR(50) NOT NULL,
cantidad int  NOT NULL
)ENGINE=InnoDB  DEFAULT CHARSET=utf8;


insert into Pedido (nombreUsuario,emailUsuario,direccionUsuario,telefonoUsuario,ccRucUsuario,entregaUsuario)
		values ('Daril Avila', 'daril_1994@hotmail.com', 'Quicentro Sur',0987091756, 0804403004, 'Domicilio');        
insert into laminasPedido(pedidoId, codigo, cantidad) values (1, 'Sp1',25); 
insert into sumatorioPedido(pedidoId, nombre, cantidad) values (1, 'Laminas',25); 

SELECT * FROM Pedido;
 
 