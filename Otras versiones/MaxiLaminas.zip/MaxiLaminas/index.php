<?php
if (!isset($_GET['paso'])) {
    $_GET['paso'] = 1;
}
$paso = $_GET['paso'];
;

//$iNumeroP=$_GET['numeroPedido'];
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Hoja de Pedidos 2017-2018</title> 
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="css/stylesEcu.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="js/laminas.js" type="text/javascript"></script>
        <script src="js/jquery-3.3.1.js" type="text/javascript"></script>
    </head>
    <body style="background-image: url(assets/img/fondoForm.jpg ); background-size:cover;" onload="cambiarHoja(); cambiarDivPasos()">             
        <div id="padre">      


            <div id="temp" >  

                <!-- margen superior -->
                <div style="padding-top: 100px;"></div>


                <!-- Tabla que muestra los pasos y sus lineas -->            
                <div>
                    <table id="pasos" style="margin: 0 auto;">                      
                        <tr>
                            <td> &nbsp; &nbsp; Paso 1 </td>
                            <td> &nbsp; &nbsp; Paso 2 </td>
                            <td> &nbsp; &nbsp; Paso 3 </td>
                            <td> &nbsp; &nbsp; Paso 4 </td>                        
                        </tr>

                        <tr>
                            <td style="padding-top: 20px;">
                                <div id="linePasos1"></div>
                            </td>
                            <td style="padding-top: 20px;">
                                <div id="linePasos2"></div>
                            </td>
                            <td style="padding-top: 20px;">
                                <div id="linePasos3"></div>
                            </td>
                            <td style="padding-top: 20px;">
                                <div id="linePasos4"></div>
                            </td>                        
                        </tr>                    
                    </table>                   
                </div>
            </div> 

            <?php
            if ($paso == 1) {
                require_once 'paso1.php';
            }
            if ($paso == 2) {
                require_once 'paso2.php';
            }
            if ($paso == 3) {
                require_once 'paso3.php';
            }
            if ($paso == 4) {
                require_once 'paso4.php';
            }
            ?>





        </div>  



    </body>
</html>
