<?php

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>HOJA DE PEDIDO</title>

    </head>
    <body style="background-image: url(img/fondoForm1.jpg ); background-size:cover;">   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      




            <!-- Formulario que almacena todos los datos -->        
            <form method="post" name="form2">

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:12px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018 <?php echo 'Pedido:' . $_SESSION['pedido']; ?> 
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>

                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            Por favor haga su pedido. No olvide seleccionar mínimo 25 UNIDADES por tema  
                                        </p>
                                    </div> 
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"></div>
                                </div>

                            </div>

                            <!-- Se crean 3 tablas diferentes para crear el formulario --> 
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">          
                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG92" id="LaminaSG92" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;92 </td>                    
                                        <td> <label for="LaminaSG92">&nbsp; &nbsp;LAS MADERAS - CLASIFICA.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG93" id="LaminaSG93" value="" min="25" max="9999" step="25"  > </td>                     
                                        <td> &nbsp; &nbsp;93 </td>                    
                                        <td> <label for="LaminaSG93">&nbsp; &nbsp;INSTRU. MUSICALES - VIENTO</label> </td>
                                    </tr>                                       
                                    <tr>
                                        <td> <input  type="number" name="SG94" id="LaminaSG94" value="" min="25" max="9999" step="25"  > </td>                   
                                        <td> &nbsp; &nbsp;94 </td>                    
                                        <td> <label for="LaminaSG94">&nbsp; &nbsp;INSTR. MUSICALES - CUERDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG95" id="LaminaSG95" value="" min="25" max="9999" step="25"  > </td>                  
                                        <td> &nbsp; &nbsp;95 </td>                    
                                        <td> <label for="LaminaSG95">&nbsp; &nbsp;INST. MUSICA. - PERCUSIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG96" id="LaminaSG96" value="" min="25" max="9999" step="25"  > </td>                   
                                        <td> &nbsp; &nbsp;96 </td>                    
                                        <td> <label for="LaminaSG96">&nbsp; &nbsp;OVÍPAROS Y VIVÍPAROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG97" id="LaminaSG97" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;97 </td>                    
                                        <td> <label for="LaminaSG97">&nbsp; &nbsp;ICARNÍ.HERVÍ Y OMÍVOROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG98" id="LaminaSG98" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;98 </td>                    
                                        <td> <label for="LaminaSG98">&nbsp; &nbsp;LA PIRÁMIDE ALIMENTICIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG99" id="LaminaSG99" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;99 </td>                    
                                        <td> <label for="LaminaSG99">&nbsp; &nbsp;TECLADO COMPUTADORA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG100" id="LaminaSG100" value="" min="25" max="9999" step="25"   > </td>                    
                                        <td> &nbsp; &nbsp;100 </td>                    
                                        <td> <label for="LaminaSG100">&nbsp; &nbsp;LOS SIETE SACARAMENTOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG101" id="LaminaSG101" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;101 </td>                    
                                        <td> <label for="LaminaSG101">&nbsp; &nbsp;LOS COLORES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG102" id="LaminaSG102" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;102 </td>                    
                                        <td> <label for="LaminaSG102">&nbsp; &nbsp;LAS FIGURAS GEOMÉTRICAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG103" id="LaminaSG103" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;103 </td>                    
                                        <td> <label for="LaminaSG103">&nbsp; &nbsp;LOS NÚMEROS DEL 0 AL 10</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG104" id="LaminaSG104" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;104 </td>                   
                                        <td> <label for="LaminaSG104">&nbsp; &nbsp;EL ABECEDARIO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG105" id="LaminaSG105" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;105 </td>                    
                                        <td> <label for="LaminaSG105">&nbsp; &nbsp;LETRA ¨A¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG106" id="LaminaSG106" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;106 </td>                    
                                        <td> <label for="LaminaSG106">&nbsp; &nbsp;LETRA ¨E¨</label> </td>
                                    </tr>                                       
                                    <tr>
                                        <td> <input  type="number" name="SG107" id="LaminaSG107" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;107 </td>                    
                                        <td> <label for="LaminaSG107">&nbsp; &nbsp;LETRA ¨I¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG108" id="LaminaSG108" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;108 </td>                    
                                        <td> <label for="LaminaSG108">&nbsp; &nbsp;LETRA ¨O¨</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG109" id="LaminaSG109" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;109 </td>                    
                                        <td> <label for="LaminaSG109">&nbsp; &nbsp;LETRA ¨U¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG110" id="LaminaSG110" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;110 </td>                    
                                        <td> <label for="LaminaSG110">&nbsp; &nbsp;EL MICROSCOPIO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG111" id="LaminaSG111" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;111 </td>                    
                                        <td> <label for="LaminaSG111">&nbsp; &nbsp;MAPA MUNDI POLÍTICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG112" id="LaminaSG112" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;112 </td>                    
                                        <td> <label for="LaminaSG112">&nbsp; &nbsp;MAPA MUNDI FÍSICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG113" id="LaminaSG113" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;113 </td>                    
                                        <td> <label for="LaminaSG113">&nbsp; &nbsp;LA CÉLULA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG114" id="LaminaSG114" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;114 </td>                    
                                        <td> <label for="LaminaSG114">&nbsp; &nbsp;MANZ. BARRIO PARROQUIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG115" id="LaminaSG115" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;115 </td>                    
                                        <td> <label for="LaminaSG115">&nbsp; &nbsp;SIST. REPROD.MASCULINO</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG116" id="LaminaSG116" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;116 </td>                    
                                        <td> <label for="LaminaSG116">&nbsp; &nbsp;SIST. REPROD.FEMENINO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG117" id="LaminaSG117" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;117 </td>                    
                                        <td> <label for="LaminaSG117">&nbsp; &nbsp;TRANSGORTES AÉREOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG118" id="LaminaSG118" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;118 </td>                    
                                        <td> <label for="LaminaSG118">&nbsp; &nbsp;TRANSGORTES MARÍTIMOS</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG119" id="LaminaSG119" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;119 </td>                    
                                        <td> <label for="LaminaSG119">&nbsp; &nbsp;RANSGORTES TERRESTRES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG120" id="LaminaSG120" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;120 </td>                    
                                        <td> <label for="LaminaSG120">&nbsp; &nbsp;APAR. REPROD.MASCULINO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG121" id="LaminaSG121" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;121 </td>                    
                                        <td> <label for="LaminaSG121">&nbsp; &nbsp;APAR. REPROD.FEMENINO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG122" id="LaminaSG122" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;122 </td>                    
                                        <td> <label for="LaminaSG122">&nbsp; &nbsp;SENTIDO DE LA VISIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG123" id="LaminaSG123" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;123 </td>                    
                                        <td> <label for="LaminaSG123">&nbsp; &nbsp;SENTIDO DE LA AUDICIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG124" id="LaminaSG124" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;124 </td>                    
                                        <td> <label for="LaminaSG124">&nbsp; &nbsp;SENTIDO DE LA OLFATO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG125" id="LaminaSG125" value="" min="25" max="9999" step="25"   > </td>                    
                                        <td> &nbsp; &nbsp;125 </td>                    
                                        <td> <label for="LaminaSG125">&nbsp; &nbsp;SENTIDO DEL GUSTO</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG126" id="LaminaSG126" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;126 </td>                    
                                        <td> <label for="LaminaSG126">&nbsp; &nbsp;SENTIDO DEL TACTO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG127" id="LaminaSG127" value="" min="25" max="9999" step="25"   > </td>                    
                                        <td> &nbsp; &nbsp;127 </td>                    
                                        <td> <label for="LaminaSG127">&nbsp; &nbsp;LOS CINCO SNETIDOS 2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG128" id="LaminaSG128" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;128 </td>                    
                                        <td> <label for="LaminaSG128">&nbsp; &nbsp;CUERPO HUMANO 2</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG39" id="LaminaSG129" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;129 </td>                    
                                        <td> <label for="LaminaSG129">&nbsp; &nbsp;LA PLANTA Y SUS PARTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG130" id="LaminaSG130" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;130 </td>                    
                                        <td> <label for="LaminaSG130">&nbsp; &nbsp;ANIMALES DOMÉSTICOS 2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG131" id="LaminaSG131" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;131 </td>                    
                                        <td> <label for="LaminaSG131">&nbsp; &nbsp;LA LETRA ¨B¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG132" id="LaminaSG132" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;132 </td>                    
                                        <td> <label for="LaminaSG132">&nbsp; &nbsp;LA LETRA ¨C¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG133" id="LaminaSG133" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;133 </td>                    
                                        <td> <label for="LaminaSG133">&nbsp; &nbsp;LA LETRA ¨CH¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG134" id="LaminaSG134" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;134 </td>                    
                                        <td> <label for="LaminaSG134">&nbsp; &nbsp;LA LETRA ¨D¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG135" id="LaminaSG135" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;135 </td>                    
                                        <td> <label for="LaminaSG135">&nbsp; &nbsp;LA LETRA ¨F¨</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG136" id="LaminaSG136" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;136 </td>                    
                                        <td> <label for="LaminaSG136">&nbsp; &nbsp;LA LETRA ¨G¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG137" id="LaminaSG137" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;137 </td>                    
                                        <td> <label for="LaminaSG137">&nbsp; &nbsp;LA LETRA ¨H¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG138" id="LaminaSG138" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;138 </td>                    
                                        <td> <label for="LaminaSG138">&nbsp; &nbsp;LA LETRA ¨J¨</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG139" id="LaminaSG139" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;139 </td>                    
                                        <td> <label for="LaminaSG139">&nbsp; &nbsp;LA LETRA ¨K¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG140" id="LaminaSG140" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;140 </td>                    
                                        <td> <label for="LaminaSG140">&nbsp; &nbsp;LA LETRA ¨L¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG141" id="LaminaSG141" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;141 </td>                    
                                        <td> <label for="LaminaSG141">&nbsp; &nbsp;LA LETRA ¨LL¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG142" id="LaminaSG142" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;142 </td>                    
                                        <td> <label for="LaminaSG142">&nbsp; &nbsp;LA LETRA ¨M¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG143" id="LaminaSG143" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;143 </td>                    
                                        <td> <label for="LaminaSG143">&nbsp; &nbsp;LA LETRA ¨N¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG144" id="LaminaSG144" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;144 </td>                    
                                        <td> <label for="LaminaSG144">&nbsp; &nbsp;LA LETRA ¨Ñ¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG145" id="LaminaSG145" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;145 </td>                    
                                        <td> <label for="LaminaSG145">&nbsp; &nbsp;LA LETRA ¨P¨</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG146" id="LaminaSG146" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;146 </td>                    
                                        <td> <label for="LaminaSG146">&nbsp; &nbsp;LA LETRA ¨Q¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG147" id="LaminaSG147" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;147 </td>                    
                                        <td> <label for="LaminaSG147">&nbsp; &nbsp;LA LETRA ¨R¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG148" id="LaminaSG148" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;148 </td>                    
                                        <td> <label for="LaminaSG148">&nbsp; &nbsp;LA LETRA ¨S¨</label> </td>
                                    <tr>
                                        <td> <input  type="number" name="SG149" id="LaminaSG149" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;149 </td>                    
                                        <td> <label for="LaminaSG149">&nbsp; &nbsp;LA LETRA ¨T¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG150" id="LaminaSG150" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;150 </td>                    
                                        <td> <label for="LaminaSG150">&nbsp; &nbsp;LA LETRA ¨V¨</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG151" id="LaminaSG151" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;151 </td>                    
                                        <td> <label for="LaminaSG151">&nbsp; &nbsp;LA LETRA ¨W¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG152" id="LaminaSG152" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;152 </td>                    
                                        <td> <label for="LaminaSG152">&nbsp; &nbsp;LA LETRA ¨X¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG153" id="LaminaSG153" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;153 </td>                    
                                        <td> <label for="LaminaSG153">&nbsp; &nbsp;LA LETRA ¨Y¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG154" id="LaminaSG154" value=""  min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;154 </td>                    
                                        <td> <label for="LaminaSG154">&nbsp; &nbsp;LA LETRA ¨Z¨</label> </td>
                                    </tr>



                                </table>

                            </div>

                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">             

                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>                                   
                                    <tr>
                                        <td> <input  type="number" name="SG21" id="LaminaSG155" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;155 </td>                    
                                        <td> <label for="LaminaSG155">&nbsp; &nbsp;LOS NÚMEROS DEL 1 AL 100</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG156" id="LaminaSG156" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;156 </td>                    
                                        <td> <label for="LaminaSG156">&nbsp; &nbsp;ANIMALES COMESTIBLES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG157" id="LaminaSG157" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;157 </td>                    
                                        <td> <label for="LaminaSG157">&nbsp; &nbsp;SERES VIVOS E INERTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG158" id="LaminaSG158" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;158 </td>                    
                                        <td> <label for="LaminaSG158">&nbsp; &nbsp;LAS FRUTAS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG159" id="LaminaSG159" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;159 </td>                    
                                        <td> <label for="LaminaSG159">&nbsp; &nbsp;LOS HUESOS DE LA CABEZA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG160" id="LaminaSG160" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;160 </td>                    
                                        <td> <label for="LaminaSG160">&nbsp; &nbsp;LAS FLORES N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG161" id="LaminaSG161" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;161 </td>                    
                                        <td> <label for="LaminaSG161">&nbsp; &nbsp;LAS CUATRO ESTACIONES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG162" id="LaminaSG162" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;162 </td>                    
                                        <td> <label for="LaminaSG162">&nbsp; &nbsp;ACCIDENTES GEOGRÁFICOS</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG163" id="LaminaSG163" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;163 </td>                    
                                        <td> <label for="LaminaSG163">&nbsp; &nbsp;HERRAM.DE ELECTRICIDAD</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG164" id="LaminaSG164" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;164 </td>                    
                                        <td> <label for="LaminaSG164">&nbsp; &nbsp;HERRAMIENT.DE PLOMERÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG21" id="LaminaSG165" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;165 </td>                    
                                        <td> <label for="LaminaSG165">&nbsp; &nbsp;INST. DE LABO. DE QUÍMICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG22" id="LaminaSG166" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;166 </td>                    
                                        <td> <label for="LaminaSG166">&nbsp; &nbsp;BANDERAS DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG167" id="LaminaSG167" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;167 </td>                    
                                        <td> <label for="LaminaSG167">&nbsp; &nbsp;BANDERAS DE EUROPA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG168" id="LaminaSG168" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;168 </td>                    
                                        <td> <label for="LaminaSG168">&nbsp; &nbsp;BANDERAS DE ÁFRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG169" id="LaminaSG169" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;169 </td>                    
                                        <td> <label for="LaminaSG169">&nbsp; &nbsp;BANDERAS DE ASIA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG170" id="LaminaSG170" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;170 </td>                    
                                        <td> <label for="LaminaSG170">&nbsp; &nbsp;CULTURA CHINA N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG171" id="LaminaSG171" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;171 </td>                    
                                        <td> <label for="LaminaSG171">&nbsp; &nbsp;CULTURA CHINA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG172" id="LaminaSG172" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;172</td>                    
                                        <td> <label for="LaminaSG172">&nbsp; &nbsp;CULTURA INDIA N°1</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG173" id="LaminaSG173" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;173</td>                    
                                        <td> <label for="LaminaSG173">&nbsp; &nbsp;CULTURA INDIA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG174" id="LaminaSG174" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;174 </td>                    
                                        <td> <label for="LaminaSG174">&nbsp; &nbsp;CULTU. MESOPOTÁMICA N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG175" id="LaminaSG175" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;175 </td>                    
                                        <td> <label for="LaminaSG175">&nbsp; &nbsp;CULTU. MESOPOTÁMICA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG176" id="LaminaSG176" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;176 </td>                    
                                        <td> <label for="LaminaSG176">&nbsp; &nbsp;CULTURA GRIEGA N°1</label> </td>
                                    </tr>
                                    <tr> 
                                        <td> <input  type="number" name="SG177" id="LaminaSG177" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;177 </td>                    
                                        <td> <label for="LaminaSG177">&nbsp; &nbsp;CULTURA GRIEGA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG178" id="LaminaSG178" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;178 </td>                    
                                        <td> <label for="LaminaSG178">&nbsp; &nbsp;CULTURA FENICIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG179" id="LaminaSG179" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;179 </td>                    
                                        <td> <label for="LaminaSG179">&nbsp; &nbsp;CULTURA GRIEGA - ATENAS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG179" id="LaminaSG176" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;179 </td>                    
                                        <td> <label for="LaminaSG179">&nbsp; &nbsp;CULTURA GRIEGA N°1</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG180" id="LaminaSG180" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;180 </td>                    
                                        <td> <label for="LaminaSG180">&nbsp; &nbsp;VALORES MORALES N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG181" id="LaminaSG181" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;181 </td>                    
                                        <td> <label for="LaminaSG181">&nbsp; &nbsp;VALORES MORALES N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG182" id="LaminaSG182" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;182 </td>                    
                                        <td> <label for="LaminaSG182">&nbsp; &nbsp;PERIFÉRICOS. DE ALMACENA.</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG183" id="LaminaSG183" value=""  min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;183</td>                    
                                        <td> <label for="LaminaSG183">&nbsp; &nbsp; PERIFÉRICOS. DE ENTRADA </label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG184" id="LaminaSG184" value="" min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;184 </td>                    
                                        <td> <label for="LaminaSG184">&nbsp; &nbsp;LA VACA Y SUS DERIVADOS</label> </td>
                                    </tr>    
                                    <tr>
                                        <td> <input  type="number" name="SG185" id="LaminaSG185" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;185 </td>                    
                                        <td> <label for="LaminaSG185">&nbsp; &nbsp;CIVILIZACIÓN PERSA</label> </td>
                                    </tr>                                                                            
                                    <tr>
                                        <td> <input  type="number" name="SG186" id="LaminaSG186" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;186 </td>                    
                                        <td> <label for="LaminaSG186">&nbsp; &nbsp;CIVILIZACIÓN HEBREA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG187" id="LaminaSG187" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;187 </td>                    
                                        <td> <label for="LaminaSG187">&nbsp; &nbsp;LA GÉLULA (GRANDE)</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG188" id="LaminaSG188" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;188 </td>                    
                                        <td> <label for="LaminaSG188">&nbsp; &nbsp;PERIFÉRICOS DE SALIDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG189" id="LaminaSG189" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;189 </td>                    
                                        <td> <label for="LaminaSG189">&nbsp; &nbsp;PART. INTERN. DE LA COMPU.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG190" id="LaminaSG190" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;190 </td>                    
                                        <td> <label for="LaminaSG190">&nbsp; &nbsp;LAS INDUSTRIAS - CLASIFI.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG191" id="LaminaSG191" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;191 </td>                    
                                        <td> <label for="LaminaSG191">&nbsp; &nbsp;HERRAM. DE ALBAÑILERÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG192" id="LaminaSG192" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;192 </td>                    
                                        <td> <label for="LaminaSG192">&nbsp; &nbsp;EL FÚTBOL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG193" id="LaminaSG193" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;193 </td>                    
                                        <td> <label for="LaminaSG193">&nbsp; &nbsp;EL BALONCESTO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG194" id="LaminaSG194" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;194 </td>                    
                                        <td> <label for="LaminaSG194">&nbsp; &nbsp;EL BÉISBOL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG195" id="LaminaSG195" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;195 </td>                    
                                        <td> <label for="LaminaSG195">&nbsp; &nbsp;EL VÓLEIBOL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG196" id="LaminaSG196" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;196 </td>                    
                                        <td> <label for="LaminaSG196">&nbsp; &nbsp;DESASTRES NATUTALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG197" id="LaminaSG197" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;197 </td>                    
                                        <td> <label for="LaminaSG197">&nbsp; &nbsp;TRAJES AMÉR.NORTE Y SUR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG198" id="LaminaSG198" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;198</td>                    
                                        <td> <label for="LaminaSG198">&nbsp; &nbsp;TRAJES AMÉRICA CENTRAL</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG199" id="LaminaSG199" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;199</td>                    
                                        <td> <label for="LaminaSG199">&nbsp; &nbsp;LA FLOR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG200" id="LaminaSG200" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;200 </td>                    
                                        <td> <label for="LaminaSG200">&nbsp; &nbsp;MONEDAS DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG201" id="LaminaSG201" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;201 </td>                    
                                        <td> <label for="LaminaSG201">&nbsp; &nbsp;MONE. ASIA - ÁFRICA - OCEAN.</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG202" id="LaminaSG202" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;202 </td>                    
                                        <td> <label for="LaminaSG202">&nbsp; &nbsp;MONEDAS DE EUROPA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG203" id="LaminaSG203" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;203 </td>                    
                                        <td> <label for="LaminaSG203">&nbsp; &nbsp;PARALELOS Y MERIDIANOS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG204" id="LaminaSG204" value=""  min="25" max="9999" step="25"> </td>                    
                                        <td> &nbsp; &nbsp;204</td>                    
                                        <td> <label for="LaminaSG204">&nbsp; &nbsp;7 MARAVILLAS MUNDO ANTÍGU.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG205" id="LaminaSG205" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;205 </td>                    
                                        <td> <label for="LaminaSG205">&nbsp; &nbsp;EL FRUTO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG206" id="LaminaSG206" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;206 </td>                    
                                        <td> <label for="LaminaSG206">&nbsp; &nbsp;EL CERDO Y SUS DERIVADOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG207" id="LaminaSG207" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;207 </td>                    
                                        <td> <label for="LaminaSG207">&nbsp; &nbsp;EL CABALLO Y SUS DERIVAD.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG208" id="LaminaSG208" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;208 </td>                    
                                        <td> <label for="LaminaSG208">&nbsp; &nbsp;LOS DIEZ MANDAMIENTOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG209" id="LaminaSG209" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;209 </td>                    
                                        <td> <label for="LaminaSG209">&nbsp; &nbsp;LOS DERECHOS DEL NIÑO</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG210" id="LaminaSG210" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;210 </td>                    
                                        <td> <label for="LaminaSG210">&nbsp; &nbsp;LOS DERECHOS HUMANOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG211" id="LaminaSG211" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;211 </td>                    
                                        <td> <label for="LaminaSG211">&nbsp; &nbsp;OFICIOS DEL HOGAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG212" id="LaminaSG212" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;212 </td>                    
                                        <td> <label for="LaminaSG212">&nbsp; &nbsp;ÚTILES ESCOLARESS</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG213" id="LaminaSG213" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;213 </td>                    
                                        <td> <label for="LaminaSG213">&nbsp; &nbsp;LA FECUNDACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG214" id="LaminaSG214" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;214 </td>                    
                                        <td> <label for="LaminaSG214">&nbsp; &nbsp;LOS ALIMENTOS CLASIFICA.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG215" id="LaminaSG215" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;215 </td>                    
                                        <td> <label for="LaminaSG215">&nbsp; &nbsp;LA SEMILLA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG216" id="LaminaSG16" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;216 </td>                    
                                        <td> <label for="LaminaSG216">&nbsp; &nbsp;ÚTILES DE ASEO PERSONAL</label> </td>
                                    </tr> 









                                </table>
                            </div>
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">           

                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG217" id="LaminaSG217" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;217 </td>                    
                                        <td> <label for="LaminaSG217">&nbsp; &nbsp;CLASES DE VESTIDOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG218" id="LaminaSG218" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;218 </td>                    
                                        <td> <label for="LaminaSG218">&nbsp; &nbsp;EL EMBARAZO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG219" id="LaminaSG219" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;219 </td>                    
                                        <td> <label for="LaminaSG219">&nbsp; &nbsp;EL PARTO Y LA LACTANCIA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG220" id="LaminaSG220" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;220 </td>                    
                                        <td> <label for="LaminaSG220">&nbsp; &nbsp;ECOSISTEMA FACTO. TIPOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG221" id="LaminaSG21" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;221 </td>                    
                                        <td> <label for="LaminaSG221">&nbsp; &nbsp;ENFERM.DE TRANS.SEXUAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG222" id="LaminaSG222" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;222 </td>                    
                                        <td> <label for="LaminaSG222">&nbsp; &nbsp;TIPOS DE COMERCIO</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG213" id="LaminaSG223" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;223 </td>                    
                                        <td> <label for="LaminaSG223">&nbsp; &nbsp;HELECHOS-MUSGOS-ALGAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG224" id="LaminaSG224" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;224 </td>                    
                                        <td> <label for="LaminaSG224">&nbsp; &nbsp;REINOS DE LA NATURALEZA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG225" id="LaminaSG225" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;215 </td>                    
                                        <td> <label for="LaminaSG215">&nbsp; &nbsp;CONTAMINACIÓN DEL SUELO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG226" id="LaminaSG226" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;226 </td>                    
                                        <td> <label for="LaminaSG226">&nbsp; &nbsp;LOS DEPORTES OLÍMPICOS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG227" id="LaminaSG227" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;227 </td>                    
                                        <td> <label for="LaminaSG227">&nbsp; &nbsp;REC.NATU.RENOV. Y NO RENOV.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG228" id="LaminaSG228" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;228 </td>                    
                                        <td> <label for="LaminaSG228">&nbsp; &nbsp;PREVEN.ACCIDENT. DEL HOGAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG209" id="LaminaSG229" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;229 </td>                    
                                        <td> <label for="LaminaSG209">&nbsp; &nbsp;CONTAMINACIÓN DEL AGUA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG230" id="LaminaSG230" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;230 </td>                    
                                        <td> <label for="LaminaSG230">&nbsp; &nbsp;CONTAMINACIÓN DEL AIRE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG231" id="LaminaSG231" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;231 </td>                    
                                        <td> <label for="LaminaSG231">&nbsp; &nbsp;SISTEMA ENDÓCRINO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG232" id="LaminaSG232" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;232 </td>                    
                                        <td> <label for="LaminaSG232">&nbsp; &nbsp;ECOSISTEMAS TERRESTRES</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG233" id="LaminaSG233" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;233 </td>                    
                                        <td> <label for="LaminaSG233">&nbsp; &nbsp;MOTIVOS NAVIDEÑOS N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG234" id="LaminaSG234" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;234 </td>                    
                                        <td> <label for="LaminaSG234">&nbsp; &nbsp;MOTIVOS NAVIDEÑOS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG235" id="LaminaSG235" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;235 </td>                    
                                        <td> <label for="LaminaSG235">&nbsp; &nbsp;MOTIVOS NAVIDEÑOS N°3</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG236" id="LaminaSG236" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;236 </td>                    
                                        <td> <label for="LaminaSG236">&nbsp; &nbsp;CANCI.NAVID. Nº1 ESPAÑOL</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG237" id="LaminaSG237" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;237 </td>                    
                                        <td> <label for="LaminaSG237">&nbsp; &nbsp;CANCIO.NAVID. Nº2 INGLÉS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG238" id="LaminaSG238" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;238 </td>                    
                                        <td> <label for="LaminaSG238">&nbsp; &nbsp;INSTRU.MUSICA.COMPLETA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG239" id="LaminaSG239" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;239 </td>                    
                                        <td> <label for="LaminaSG239">&nbsp; &nbsp;LAS BACTERIAS</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG240" id="LaminaSG240" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;240 </td>                    
                                        <td> <label for="LaminaSG240">&nbsp; &nbsp;LOS VIRUS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG241" id="LaminaSG241" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;241 </td>                    
                                        <td> <label for="LaminaSG241">&nbsp; &nbsp;SEÑALES DE TRÁNSITO N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG242" id="LaminaSG242" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;242 </td>                    
                                        <td> <label for="LaminaSG242">&nbsp; &nbsp;SEÑALES DE TRÁNSITO N°2</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG243" id="LaminaSG243" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;243 </td>                    
                                        <td> <label for="LaminaSG243">&nbsp; &nbsp;FECHAS IMPORT.DEL MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG244" id="LaminaSG44" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;244 </td>                    
                                        <td> <label for="LaminaSG244">&nbsp; &nbsp;PLANTAS ALIMENTICIAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG245" id="LaminaSG245" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;245 </td>                    
                                        <td> <label for="LaminaSG245">&nbsp; &nbsp;ESCUELA Y SUS DEPENDEN.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG246" id="LaminaSG246" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;246 </td>                    
                                        <td> <label for="LaminaSG246">&nbsp; &nbsp;EL SOL</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG247" id="LaminaSG247" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;247 </td>                    
                                        <td> <label for="LaminaSG247">&nbsp; &nbsp;LA LUNA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG248" id="LaminaSG248" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;248 </td>                    
                                        <td> <label for="LaminaSG248">&nbsp; &nbsp;GENERACIÓN DE COMPUTA.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG249" id="LaminaSG249" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;249 </td>                    
                                        <td> <label for="LaminaSG249">&nbsp; &nbsp;LA CREACIÓN DEL MUNDO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG250" id="LaminaSG250" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;250 </td>                    
                                        <td> <label for="LaminaSG250">&nbsp; &nbsp;LA EVOLUCIÓN DEL HOMBRE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG251" id="LaminaSG251" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;251 </td>                    
                                        <td> <label for="LaminaSG251">&nbsp; &nbsp;LA ORIENTACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG252" id="LaminaSG252" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;252 </td>                    
                                        <td> <label for="LaminaSG252">&nbsp; &nbsp;LA FORMA DE LA TIERRA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG253" id="LaminaSG253" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;253 </td>                    
                                        <td> <label for="LaminaSG253">&nbsp; &nbsp;LA ESTRUCTURA DE LA TIERRA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG254" id="LaminaSG54" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;254 </td>                    
                                        <td> <label for="LaminaSG254">&nbsp; &nbsp;THE ALPHABET - ALFABETO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG255" id="LaminaSG255" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;255 </td>                    
                                        <td> <label for="LaminaSG255">&nbsp; &nbsp;THE NUMBERS - NÚMEROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG256" id="LaminaSG256" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;256 </td>                    
                                        <td> <label for="LaminaSG256">&nbsp; &nbsp;THE COLORS - COLORES</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG257" id="LaminaSG257" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;257 </td>                    
                                        <td> <label for="LaminaSG257">&nbsp; &nbsp;THE GREETINGS-SALUDOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG258" id="LaminaSG258" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;258 </td>                    
                                        <td> <label for="LaminaSG258">&nbsp; &nbsp;THE FEELINGS-SENTIMIENTOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG259" id="LaminaSG259" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;259 </td>                    
                                        <td> <label for="LaminaSG259">&nbsp; &nbsp;HUMAN BODY-CUERPO HUM.</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG260" id="LaminaSG60" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;260 </td>                    
                                        <td> <label for="LaminaSG260">&nbsp; &nbsp;THE FAMILY - LA FAMILIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG261" id="LaminaSG261" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;261 </td>                    
                                        <td> <label for="LaminaSG261">&nbsp; &nbsp;MY SCHOOL - LA ESCUELA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG262" id="LaminaSG262" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;262 </td>                    
                                        <td> <label for="LaminaSG262">&nbsp; &nbsp;THE WEATHER - EL CLIMA</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG263" id="LaminaSG263" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;263 </td>                    
                                        <td> <label for="LaminaSG263">&nbsp; &nbsp;THE CALENDER- CALENDARIO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG264" id="LaminaSG64" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;264 </td>                    
                                        <td> <label for="LaminaSG264">&nbsp; &nbsp;FRUITS AND VEGETABLES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG265" id="LaminaSG265" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;265 </td>                    
                                        <td> <label for="LaminaSG265">&nbsp; &nbsp;PETS AND FARM ANIMALS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG266" id="LaminaSG266" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;266 </td>                    
                                        <td> <label for="LaminaSG266">&nbsp; &nbsp;FOOD PYRAMID</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG267" id="LaminaSG267" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;267 </td>                    
                                        <td> <label for="LaminaSG267">&nbsp; &nbsp;SECTORES DE LA PRODU.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG268" id="LaminaSG268" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;268 </td>                    
                                        <td> <label for="LaminaSG268">&nbsp; &nbsp;DISECCIÓN RANA Y LAGARTO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG269" id="LaminaSG269" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;269 </td>                    
                                        <td> <label for="LaminaSG269">&nbsp; &nbsp;DISECCIÓN PALOMA Y CONEJO</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG270" id="LaminaSG270" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;270 </td>                    
                                        <td> <label for="LaminaSG270">&nbsp; &nbsp;TEJIDOS ANIMALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG271" id="LaminaSG271" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;271 </td>                    
                                        <td> <label for="LaminaSG271">&nbsp; &nbsp;TEJIDOS VEGETALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG272" id="LaminaSG272" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;272 </td>                    
                                        <td> <label for="LaminaSG272">&nbsp; &nbsp;PLANTAS TERRESTRES</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG273" id="LaminaSG273" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;273 </td>                    
                                        <td> <label for="LaminaSG273">&nbsp; &nbsp;PLANTAS TREPADORAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG274" id="LaminaSG74" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;274 </td>                    
                                        <td> <label for="LaminaSG274">&nbsp; &nbsp;PLANTAS AÉREAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG274" id="LaminaSG275" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;275 </td>                    
                                        <td> <label for="LaminaSG275">&nbsp; &nbsp;PLANTAS ACUÁTICAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG276" id="LaminaSG276" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;276 </td>                    
                                        <td> <label for="LaminaSG276">&nbsp; &nbsp;ERAS GEOLÓGICAS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG277" id="LaminaSG277" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;277 </td>                    
                                        <td> <label for="LaminaSG277">&nbsp; &nbsp;FORMAS DE LENGUAJE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG278" id="LaminaSG278" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;278 </td>                    
                                        <td> <label for="LaminaSG278">&nbsp; &nbsp;LA VIOLENCIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG279" id="LaminaSG279" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;279 </td>                    
                                        <td> <label for="LaminaSG279">&nbsp; &nbsp;ANIMALES ACUÁTICOS</label> </td>
                                    </tr> 


                                </table>
                            </div>










                        </div>

                    </div>







            </form>






        </div>
    </body>

</html>