/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



// este codigo obtiene datos de la url
function getUrl(arg) {
    query = window.location.search.substring(1);
    q = query.split("&");
    vars = [];
    for (i = 0; i < q.length; i++) {
        x = q[i].split("=");
        k = x[0];
        v = x[1];
        vars[k] = v;
    }
    return vars[arg];


}

function cambiarDivPasos() {
    pasoAct = getUrl('paso');

    if (pasoAct == 1) {

        document.getElementById("linePasos1").style.height = '5px';

    }
    if (pasoAct == 2) {

        document.getElementById("linePasos2").style.height = '5px';


    }
    if (pasoAct == 3) {

        document.getElementById("linePasos3").style.height = '5px';

    }
    if (pasoAct == 4) {

        document.getElementById("linePasos4").style.height = '5px';

    }

}

function cambiarHoja() {
    pagAct = getUrl('hoja');

    var atras = document.getElementById("antes");
    var delante = document.getElementById("despues");

    if (pagAct == 1) {
        atras.style.visibility = "hidden";
        delante.href = '?paso=2&hoja=2';

    }
    if (pagAct == 2) {
        delante.href = '?paso=2&hoja=3';
        atras.href = '?paso=2&hoja=1';
    }

    if (pagAct == 3) {
        delante.href = '?paso=2&hoja=4';
        atras.href = '?paso=2&hoja=2';

    }

    if (pagAct == 4) {
        delante.style.visibility = "hidden";
        atras.href = "?paso=2&hoja=3";
    }
}


function guardarForm() {
    var formEnviar;
    formAct = getUrl('hoja');

    if (formAct === 1) {
        formEnviar = "form1";
    }
    if (formAct === 2) {
        formEnviar = "for2";
    }
    if (formAct === 3) {
        formEnviar = "form3";
    }
    if (formAct === 4) {
        formEnviar = "form4";
    }
    document.form(formEnviar).subtmit;
    alert("ME active");


}