<?php

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>HOJA DE PEDIDO</title>

    </head>
    <body style="background-image: url(img/fondoForm1.jpg ); background-size:cover;">   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      




            <!-- Formulario que almacena todos los datos -->        
            <form method="post" name="form4" >

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:12px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018  <?php echo 'Pedido:' . $_SESSION['pedido']; ?> 
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>

                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            Por favor haga su pedido. No olvide seleccionar mínimo 25 UNIDADES por tema  
                                        </p>
                                    </div> 
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"></div>
                                </div>

                            </div>

                            <!-- Se crean 3 tablas diferentes para crear el formulario --> 
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">          
                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG469" id="LaminaSG469" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;469 </td>                    
                                        <td> <label for="LaminaSG469">&nbsp; &nbsp;POTABILIZACIÓN DEL AGUA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG470" id="LaminaSG470" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;470 </td>                    
                                        <td> <label for="LaminaSG470">&nbsp; &nbsp;BIOMA BOSQUE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG471" id="LaminaSG471" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;471 </td>                    
                                        <td> <label for="LaminaSG471">&nbsp; &nbsp;BIOMA PASTIZAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG472" id="LaminaSG472" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;472 </td>                    
                                        <td> <label for="LaminaSG472">&nbsp; &nbsp;LA MIGRACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG473" id="LaminaSG473" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;473 </td>                    
                                        <td> <label for="LaminaSG473">&nbsp; &nbsp;LA COMPUTAD.Y SUS PARTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG474" id="LaminaSG474" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;474 </td>                    
                                        <td> <label for="LaminaSG474">&nbsp; &nbsp;LAS PROFESIONES N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG475" id="LaminaSG475" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;475 </td>                    
                                        <td> <label for="LaminaSG475">&nbsp; &nbsp;OBJETOS COLOR BLANCO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG476" id="LaminaSG476" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;476</td>                    
                                        <td> <label for="LaminaSG476">&nbsp; &nbsp;OBJETOS COLOR NEGRO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG477" id="LaminaSG477" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;477</td>                    
                                        <td> <label for="LaminaSG477">&nbsp; &nbsp;OBJETOS COLOR ROSADO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG478" id="LaminaSG478" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;478 </td>                    
                                        <td> <label for="LaminaSG478">&nbsp; &nbsp;OBJETOS COLOR CAFÉ</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG479" id="LaminaSG479" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;479 </td>                    
                                        <td> <label for="LaminaSG479">&nbsp; &nbsp;LOS OFICIOS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG480" id="LaminaSG480" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;480 </td>                    
                                        <td> <label for="LaminaSG480">&nbsp; &nbsp;ÍCONOS DE LA COMPUTADO.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG481" id="LaminaSG481" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;481 </td>                    
                                        <td> <label for="LaminaSG481">&nbsp; &nbsp;CULTURA CHIBCHA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG482" id="LaminaSG482" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;482 </td>                    
                                        <td> <label for="LaminaSG482">&nbsp; &nbsp;ANIMALES SILVESTRES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG483" id="LaminaSG483" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;483 </td>                    
                                        <td> <label for="LaminaSG483">&nbsp; &nbsp;CULTURA OLMECA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG484" id="LaminaSG484" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;484 </td>                    
                                        <td> <label for="LaminaSG484">&nbsp; &nbsp;EDUCACIÓN VIAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG485" id="LaminaSG485" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;485 </td>                    
                                        <td> <label for="LaminaSG485">&nbsp; &nbsp;IMPER.DEL TAHUANTINSUYIO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG486" id="LaminaSG486" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;486</td>                    
                                        <td> <label for="LaminaSG486">&nbsp; &nbsp;CUENTOS CLÁSICOS N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG487" id="LaminaSG487" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;487</td>                    
                                        <td> <label for="LaminaSG487">&nbsp; &nbsp;CUENTOS CLÁSICOS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG47" id="LaminaSG488" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;488 </td>                    
                                        <td> <label for="LaminaSG488">&nbsp; &nbsp;CUENTOS CLÁSICOS N°3</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG489" id="LaminaSG489" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;489 </td>                    
                                        <td> <label for="LaminaSG489">&nbsp; &nbsp;PRIN.VIRTUDES DEL HOMBRE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG490" id="LaminaSG490" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;490 </td>                    
                                        <td> <label for="LaminaSG490">&nbsp; &nbsp;LOS SABORES Y OLORES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG491" id="LaminaSG491" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;491 </td>                    
                                        <td> <label for="LaminaSG491">&nbsp; &nbsp;EL PADRE NUESTRO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG492" id="LaminaSG492" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;492 </td>                    
                                        <td> <label for="LaminaSG492">&nbsp; &nbsp;LA GUERRA FRÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG493" id="LaminaSG493" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;493 </td>                    
                                        <td> <label for="LaminaSG493">&nbsp; &nbsp;RELIGIONES DEL MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG494" id="LaminaSG494" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;494 </td>                    
                                        <td> <label for="LaminaSG494">&nbsp; &nbsp;LOS ESTADOS DEL AGUA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG495" id="LaminaSG495" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;495 </td>                    
                                        <td> <label for="LaminaSG495">&nbsp; &nbsp;TECLADO COMPUTADORA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG496" id="LaminaSG496" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;496</td>                    
                                        <td> <label for="LaminaSG496">&nbsp; &nbsp;PRINCIPALES DEPORTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG497" id="LaminaSG497" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;497</td>                    
                                        <td> <label for="LaminaSG497">&nbsp; &nbsp;PROBLEM.INTRAFAMILIARES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG498" id="LaminaSG498" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;498 </td>                    
                                        <td> <label for="LaminaSG498">&nbsp; &nbsp;CICLO DEL OXÍGENO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG499" id="LaminaSG499" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;499 </td>                    
                                        <td> <label for="LaminaSG499">&nbsp; &nbsp;PRINCIPALES DEPORTES Nº1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG500" id="LaminaSG500" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;500 </td>                    
                                        <td> <label for="LaminaSG500">&nbsp; &nbsp;JUGUETES NIÑOS Y NIÑAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG501" id="LaminaSG501" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;501 </td>                    
                                        <td> <label for="LaminaSG501">&nbsp; &nbsp;OBJETOS FORMA OVALADA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG502" id="LaminaSG502" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;502 </td>                    
                                        <td> <label for="LaminaSG502">&nbsp; &nbsp;OBJETOS FORMA REDONDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG503" id="LaminaSG503" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;503 </td>                    
                                        <td> <label for="LaminaSG503">&nbsp; &nbsp;OBJETOS FORMA CUADRADA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG504" id="LaminaSG504" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;504 </td>                    
                                        <td> <label for="LaminaSG504">&nbsp; &nbsp;OBJETOS F. RECTANGULAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG505" id="LaminaSG505" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;505 </td>                    
                                        <td> <label for="LaminaSG505">&nbsp; &nbsp;OBJETOS FOR.TRIANGULAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG506" id="LaminaSG506" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;506</td>                    
                                        <td> <label for="LaminaSG506">&nbsp; &nbsp;OBJETOS FOR. ROMBOIDE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG507" id="LaminaSG507" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;507</td>                    
                                        <td> <label for="LaminaSG507">&nbsp; &nbsp;OBJETOS FOR. CILÍNDRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG508" id="LaminaSG508" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;508 </td>                    
                                        <td> <label for="LaminaSG508">&nbsp; &nbsp;OBJETOS FORMA CÓNICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG509" id="LaminaSG509" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;509 </td>                    
                                        <td> <label for="LaminaSG509">&nbsp; &nbsp;SISTEMA LOCOMOTOR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG510" id="LaminaSG510" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;510 </td>                    
                                        <td> <label for="LaminaSG510">&nbsp; &nbsp;ANIMALES INSECTÍVOROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG511" id="LaminaSG511" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;511 </td>                    
                                        <td> <label for="LaminaSG471">&nbsp; &nbsp;JUEGOS TRADICIONALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG472" id="LaminaSG512" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;512 </td>                    
                                        <td> <label for="LaminaSG472">&nbsp; &nbsp;ALIMENTOS ENERGÉTICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG513" id="LaminaSG513" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;513 </td>                    
                                        <td> <label for="LaminaSG513">&nbsp; &nbsp;ALIMENTOS REGULADORES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG514" id="LaminaSG514" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;514 </td>                    
                                        <td> <label for="LaminaSG514">&nbsp; &nbsp;ALIMENTOS CONSTRUCTORES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG515" id="LaminaSG515" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;515 </td>                    
                                        <td> <label for="LaminaSG515">&nbsp; &nbsp;ALIM.ORIGEN ANIM-VEGET</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG516" id="LaminaSG516" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;516</td>                    
                                        <td> <label for="LaminaSG516">&nbsp; &nbsp;HIGIENE DE LA ALIMENTACIÓN</label> </td>
                                    </tr>
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS EDUCARTE </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD1" id="LaminaEGD1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D1</td>                    
                                        <td> <label for="LaminaEGD1">&nbsp; &nbsp;CLASIF. ANIMALES SALVAJES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD2" id="LaminaEGD2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D2</td>                    
                                        <td> <label for="LaminaEGD2">&nbsp; &nbsp;ANIMALES PREHISTÓRICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD3" id="LaminaEGD3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D3</td>                    
                                        <td> <label for="LaminaEGD3">&nbsp; &nbsp;ANIMALES DE LA GRANJA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD4" id="LaminaEGD4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D4</td>                    
                                        <td> <label for="LaminaEGD4">&nbsp; &nbsp;CLASIFIC. DE LOS ANIMALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD5" id="LaminaEGD5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D5</td>                    
                                        <td> <label for="LaminaEGD5">&nbsp; &nbsp;CLASIF. ANIMALES SALVAJES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD6" id="LaminaEGD6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D6</td>                    
                                        <td> <label for="LaminaEGD6">&nbsp; &nbsp;LENGUAJE DE LOS ANIMALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD7" id="LaminaEGD7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D7</td>                    
                                        <td> <label for="LaminaEGD7">&nbsp; &nbsp;PECES AGUA DULCE Y SALADA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD8" id="LaminaEGD8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D8</td>                    
                                        <td> <label for="LaminaEGD1">&nbsp; &nbsp;CLASIFICACIÓN ROEDORES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD9" id="LaminaEGD9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D9</td>                    
                                        <td> <label for="LaminaEGD9">&nbsp; &nbsp;CLASIFICACIÓN MARIPOSAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD10" id="LaminaEGD10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D10</td>                    
                                        <td> <label for="LaminaEGD10">&nbsp; &nbsp;ANFIBIOS CLASIFICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD11" id="LaminaEGD11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D11</td>                    
                                        <td> <label for="LaminaEGD11">&nbsp; &nbsp;REPTILES CLASIFICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD12" id="LaminaEGD12" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D12</td>                    
                                        <td> <label for="LaminaEGD12">&nbsp; &nbsp;FAUNA DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGD13" id="LaminaEGD13" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;D13</td>                    
                                        <td> <label for="LaminaEGD13">&nbsp; &nbsp;ANIMALES CARROÑEROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGF1" id="LaminaEGF1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;F1</td>                    
                                        <td> <label for="LaminaEGF1">&nbsp; &nbsp;CLASIFI. MEDIOS COMUNICA.</label> </td>
                                    </tr>






                                </table>

                            </div>

                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px; padding-bottom: 4%;">             

                                <table class="textI">
                                    <tr>   
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>  
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGG5" id="LaminaEGG5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;G5</td>                    
                                        <td> <label for="LaminaEGG5">&nbsp; &nbsp;LA DEMOCRACIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI1" id="LaminaEGI1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I1</td>                    
                                        <td> <label for="LaminaEGI1">&nbsp; &nbsp; MINERALES METÁLICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI2" id="LaminaEGI2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I2</td>                    
                                        <td> <label for="LaminaEGI2">&nbsp; &nbsp;MINERALES NO METÁLICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI3" id="LaminaEGI3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I3</td>                    
                                        <td> <label for="LaminaEGI3">&nbsp; &nbsp;CICLO DEL NITRÓGENO</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="EGI4" id="LaminaEGI4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I4</td>                    
                                        <td> <label for="LaminaEGI4">&nbsp; &nbsp;CICLO DEL CARBONO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI6" id="LaminaEGI6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I6</td>                    
                                        <td> <label for="LaminaEGI6">&nbsp; &nbsp;CONTAM. MEDIO AMBIENTE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI8" id="LaminaEGI8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I8</td>                    
                                        <td> <label for="LaminaEGI8">&nbsp; &nbsp;EDUCACIÓN AMBIENTAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI9" id="LaminaEGI9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I9</td>                    
                                        <td> <label for="LaminaEGI9">&nbsp; &nbsp;VE. ORG. DE LA NATURAL.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI10" id="LaminaEGI10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I10</td>                    
                                        <td> <label for="LaminaEGI10">&nbsp; &nbsp;LA NATURALEZA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGI11" id="LaminaEGI11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;I11</td>                    
                                        <td> <label for="LaminaEGI11">&nbsp; &nbsp;RELACIO. DE LAS ESPECIES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGK6" id="LaminaEGK6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;K6</td>                    
                                        <td> <label for="LaminaEGK6">&nbsp; &nbsp;LA POBREZA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGK7" id="LaminaEGK7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;K7</td>                    
                                        <td> <label style="font-size: 11px;" for="LaminaEGK7">&nbsp; &nbsp;PRENDAS Y ACCES. DE VESTIR</label> </td>
                                    </tr>                                         
                                    <tr>
                                        <td> <input  type="number" name="EGK8" id="LaminaEGK8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;K8</td>                    
                                        <td> <label for="LaminaEGK8">&nbsp; &nbsp;PARROQ. URBANA Y RURAL</label> </td>
                                    </tr>                                         
                                    <tr>
                                        <td> <input  type="number" name="EGK9" id="LaminaEGK9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;K9</td>                    
                                        <td> <label for="LaminaEGK9">&nbsp; &nbsp;EL BARRIO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGL1" id="LaminaEGL1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;L1</td>                    
                                        <td> <label for="LaminaEGL1">&nbsp; &nbsp;CLASIFIC. DE LOS NÚMEROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGL2" id="LaminaEGL2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;L2</td>                    
                                        <td> <label for="LaminaEGL2">&nbsp; &nbsp;FIGURAS GEOMÉT. PLANAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGL3" id="LaminaEGL3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;L3</td>                    
                                        <td> <label for="LaminaEGL3">&nbsp; &nbsp;TIPOS DE LÍNEAS Y ÁNGULOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGL4" id="LaminaEGL4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;L4</td>                    
                                        <td> <label for="LaminaEGL4">&nbsp; &nbsp;UNIDADES DE MEDIDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGM1" id="LaminaEGM1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;M1</td>                    
                                        <td> <label for="LaminaEGM1">&nbsp; &nbsp;ALFABETO INGLÉS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGQ1" id="LaminaEGQ1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;Q1</td>                    
                                        <td> <label for="LaminaEGQ1">&nbsp; &nbsp;CLASES DE ENERGÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGQ2" id="LaminaEGQ2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;Q2</td>                    
                                        <td> <label for="LaminaEGQ2">&nbsp; &nbsp;INSTR. LABORAT. DE FÍSICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP1" id="LaminaEGP1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P1</td>                    
                                        <td> <label for="LaminaEGP1">&nbsp; &nbsp;REFORMA Y CONTRAREFO.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP2" id="LaminaEGP2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P2</td>                    
                                        <td> <label for="LaminaEGP2">&nbsp; &nbsp;LA ESCLAVITUD</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP3" id="LaminaEGP3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P3</td>                    
                                        <td> <label for="LaminaEGP3">&nbsp; &nbsp;EL ABSOLUTISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP5" id="LaminaEGP5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P5</td>                    
                                        <td> <label for="LaminaEGP5">&nbsp; &nbsp;EL FEUDALISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP6" id="LaminaEGP6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P6</td>                    
                                        <td> <label for="LaminaEGP6">&nbsp; &nbsp;EL CAPITALISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP7" id="LaminaEGP7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P7</td>                    
                                        <td> <label for="LaminaEGP7">&nbsp; &nbsp;SOCIALISMO Y COMUNISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP9" id="LaminaEGP9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P9</td>                    
                                        <td> <label for="LaminaEGP9">&nbsp; &nbsp;EL MERCANTILISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGP11" id="LaminaEGP11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;P11</td>                    
                                        <td> <label for="LaminaEGP11">&nbsp; &nbsp;LAS CRUZADAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGQ1" id="LaminaEGQ1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;Q1</td>                    
                                        <td> <label for="LaminaEGQ1">&nbsp; &nbsp;INSTR. MUSI. FOLCLÓRICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGQ2" id="LaminaEGQ2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;Q2</td>                    
                                        <td> <label for="LaminaEGQ2">&nbsp; &nbsp;SIGNOS MUSICALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR3" id="LaminaEGR3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R3</td>                    
                                        <td> <label for="LaminaEGR3">&nbsp; &nbsp;OCÉAN. MARES DEL MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR4" id="LaminaEGR4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R4</td>                    
                                        <td> <label for="LaminaEGR4">&nbsp; &nbsp;MOVIMIENT. TERRÁQUEOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR5" id="LaminaEGR5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R5</td>                    
                                        <td> <label for="LaminaEGR5">&nbsp; &nbsp;ESTACIO. CLIMA TIEMPO ATM.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR8" id="LaminaEGR8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R8</td>                    
                                        <td> <label for="LaminaEGR8">&nbsp; &nbsp;TEORÍAS ORUGEN DE LA VIDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR9" id="LaminaEGR9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R9</td>                    
                                        <td> <label for="LaminaEGR9">&nbsp; &nbsp;CORRIENTES MARINAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR10" id="LaminaEGR10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R10</td>                    
                                        <td> <label for="LaminaEGR10">&nbsp; &nbsp;EL DÍA Y LA NOCHE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGR11" id="LaminaEGR11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;R11</td>                    
                                        <td> <label for="LaminaEGR11">&nbsp; &nbsp;LOS CUERPOS CELESTES</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="EGT1" id="LaminaEGT1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T1</td>                    
                                        <td> <label for="LaminaEGT1">&nbsp; &nbsp;PLANTAS ÚTILES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGT3" id="LaminaEGT3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T3</td>                    
                                        <td> <label for="LaminaEGT3">&nbsp; &nbsp;ALIMENTA. DE LAS PLANTAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGT4" id="LaminaEGT4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T4</td>                    
                                        <td> <label for="LaminaEGT4">&nbsp; &nbsp;CLASES DE MADERAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGT5" id="LaminaEGT5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T5</td>                    
                                        <td> <label for="LaminaEGT5">&nbsp; &nbsp;LA GERMINACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGT6" id="LaminaEGT6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T6</td>                    
                                        <td> <label for="LaminaEGT6">&nbsp; &nbsp;FLORA DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGT9" id="LaminaEGT9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;T9</td>                    
                                        <td> <label for="LaminaEGT9">&nbsp; &nbsp;BIOMA MANGLAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="EGV1" id="LaminaEGV1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;V1</td>                    
                                        <td> <label for="LaminaEGV1">&nbsp; &nbsp;LAS DISCAPACIDADES</label> </td>
                                    </tr>

                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; CROQUIS</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; COD: 7862102821876</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ1" id="LaminaCQ1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ1</td>                    
                                        <td> <label for="LaminaCQ1">&nbsp; &nbsp;MAPA POLÍTICO DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ2" id="LaminaCQ2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ2</td>                    
                                        <td> <label for="LaminaCQ2">&nbsp; &nbsp;MAPA POLÍTICO DE ASIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ3" id="LaminaCQ3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ3</td>                    
                                        <td> <label for="LaminaCQ3">&nbsp; &nbsp;MAPA POLÍTICO DE ÁFRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ4" id="LaminaCQ4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ4</td>                    
                                        <td> <label for="LaminaCQ4">&nbsp; &nbsp;MAPA POLÍTICO DE EUROPA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ5" id="LaminaCQ5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ5</td>                    
                                        <td> <label for="LaminaCQ5">&nbsp; &nbsp;MAPA POLÍTICO DE PANAMÁ</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ6" id="LaminaCQ6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ6</td>                    
                                        <td> <label for="LaminaCQ6">&nbsp; &nbsp;MAPA FÍSICO DE PANAMÁ</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ7" id="LaminaCQ7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ7</td>                    
                                        <td> <label for="LaminaCQ7">&nbsp; &nbsp;MAPA MUNDI POLÍTICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ8" id="LaminaCQ8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ8</td>                    
                                        <td> <label for="LaminaCQ8">&nbsp; &nbsp;MAPA FÍSICO DE AMÉRICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ9" id="LaminaCQ9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CQ9</td>                    
                                        <td> <label for="LaminaCQ9">&nbsp; &nbsp;MAPA FÍSICO DE ASIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CQ10" id="LaminaCQ10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td>  &nbsp;CQ10</td>                    
                                        <td> <label for="LaminaCQ10">&nbsp; &nbsp;MAPA FÍSICO DE ASIA</label> </td>
                                    </tr>

                                    <tr>
                                        <td> <input  type="number" name="CQ11" id="LaminaCQ11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp;CQ11</td>                    
                                        <td> <label for="LaminaCQ11">&nbsp; &nbsp;MAPA FÍSICO DE EUROPA</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CQ12" id="LaminaCQ12" value="" min="25" max="9999" step="25" > </td>                    
                                        <td>  &nbsp;CQ12</td>                    
                                        <td > <label for="LaminaCQ12">&nbsp; &nbsp;MAPA MUNDI FÍSICO</label> </td>
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp;TABLA ELEMENTOS QUÍMICOS</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; COD: 7862102821869</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="TP" id="LaminaTP" value="" min="25" max="9999" step="25" > </td>                    
                                        <td>  &nbsp;TP</td>                    
                                        <td> <label for="LaminaTP">&nbsp; &nbsp;TABLA PERIÓDICA ELEMENTOS</label> </td>
                                    </tr>





                                </table>
                            </div>
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px; padding-bottom: 7.8%">           

                                <table class="textI">

                                    <tr> 
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp;CARTILLA DE LAS 4 OPERACIONES</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3" > &nbsp; &nbsp; COD: 9780201379624</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CB" id="LaminaCB" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CB</td>                    
                                        <td> <label for="LaminaCB">&nbsp; &nbsp;CARTILLA 4 OPERACIONES B</label> </td>
                                    </tr>
                                    <td class="textC negrita" colspan="3"> &nbsp; &nbsp;LAMINAS ARMABLES PARA MAQUETA</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3" style="padding-bottom: 8px;"> &nbsp; &nbsp;COD: 7862102821869</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="A1" id="LaminaA1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A1</td>                    
                                        <td> <label for="LaminaA1">&nbsp; &nbsp;CASA RURAL</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A2" id="LaminaA2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A2</td>                    
                                        <td> <label for="LaminaA2">&nbsp; &nbsp;CASA URBANA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A3" id="LaminaA3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A3</td>                    
                                        <td> <label for="LaminaA3">&nbsp; &nbsp;SUPERMERCADO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A4" id="LaminaA4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A4</td>                    
                                        <td> <label for="LaminaA4">&nbsp; &nbsp;ESCUELA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A5" id="LaminaA5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A5</td>                    
                                        <td> <label for="LaminaA5">&nbsp; &nbsp;ESTACIÓN DE BOMBEROS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A6" id="LaminaA6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A6</td>                    
                                        <td> <label for="LaminaA6">&nbsp; &nbsp;EDIFICIO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A7" id="LaminaA7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A7</td>                    
                                        <td> <label for="LaminaA7">&nbsp; &nbsp;CENTRO DE SALUD</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A8" id="LaminaA8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A8</td>                    
                                        <td> <label for="LaminaA8">&nbsp; &nbsp;BIBLIOTECA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A9" id="LaminaA9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A9</td>                    
                                        <td> <label for="LaminaA9">&nbsp; &nbsp;IGLESIA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A10" id="LaminaA10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A10</td>                    
                                        <td> <label for="LaminaA10">&nbsp; &nbsp;ESTACIÓN DE POLICÍA</label> </td>
                                    </tr> 

                                    <tr>
                                        <td> <input  type="number" name="A11" id="LaminaA11" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A11</td>                    
                                        <td> <label for="LaminaA11">&nbsp; &nbsp;BANCO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A12" id="LaminaA12" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A12</td>                    
                                        <td> <label for="LaminaA12">&nbsp; &nbsp;HOSPITAL</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A13" id="LaminaA13" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A13</td>                    
                                        <td> <label for="LaminaA13">&nbsp; &nbsp;CASA DE ADOBE O BARRO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A14" id="LaminaA14" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A14</td>                    
                                        <td> <label for="LaminaA14">&nbsp; &nbsp;CASA DE PIEDRA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A15" id="LaminaA15" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A5</td>                    
                                        <td> <label for="LaminaA15">&nbsp; &nbsp;CASA DE MADERA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A16" id="LaminaA16" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A16</td>                    
                                        <td> <label for="LaminaA16">&nbsp; &nbsp;CASA DE CEMENTO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A17" id="LaminaA17" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A17</td>                    
                                        <td> <label for="LaminaA17">&nbsp; &nbsp;EL ESTADIO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A18" id="LaminaA18" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A18</td>                    
                                        <td> <label for="LaminaA18">&nbsp; &nbsp;EL AEROPUERTO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A19" id="LaminaA19" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A19</td>                    
                                        <td> <label for="LaminaA19">&nbsp; &nbsp;LA GASOLINERA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A20" id="LaminaA20" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A20</td>                    
                                        <td> <label for="LaminaA20">&nbsp; &nbsp;LA COMPUTADORA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A21" id="LaminaA21" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A21</td>                    
                                        <td> <label for="LaminaA21">&nbsp; &nbsp;EL PARQUE</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A22" id="LaminaA22" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A22</td>                    
                                        <td> <label for="LaminaA22">&nbsp; &nbsp;EL MERCADO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A23" id="LaminaA23" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A23</td>                    
                                        <td> <label for="LaminaA23">&nbsp; &nbsp;LA FARMACIA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A24" id="LaminaA24" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A24</td>                    
                                        <td> <label for="LaminaA24">&nbsp; &nbsp;LA FERRETERIA</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A25" id="LaminaA25" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A25</td>                    
                                        <td> <label for="LaminaA25">&nbsp; &nbsp;ÁRBOLES - SEMÁFOROS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="A26" id="LaminaA26" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;A26</td>                    
                                        <td> <label for="LaminaA26">&nbsp; &nbsp;PERSONAS - ANIMALES</label> </td>
                                    </tr> 
                                    <td class="textC negrita" colspan="3" style="padding-bottom:0px;"> &nbsp; &nbsp;CARTELES GRANDES (65x45 cm.)</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3" style="padding-bottom: 8px;"> &nbsp; &nbsp;COD: 7862102822002</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CG1" id="LaminaCG1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG1</td>                    
                                        <td> <label for="LaminaCG1">&nbsp; &nbsp;SÍMBOLOS PATRIOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CG2" id="LaminaCG2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG2</td>                    
                                        <td> <label for="LaminaCG2">&nbsp; &nbsp;EL VIA CRUSIS</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG3" id="LaminaCG3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG3</td>                    
                                        <td> <label for="LaminaCG3">&nbsp; &nbsp;REGRESO A CLASES 1</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG4" id="LaminaCG4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG4</td>                    
                                        <td> <label for="LaminaCG4">&nbsp; &nbsp;REGRESO A CLASES 2</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG5" id="LaminaCG5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG5</td>                    
                                        <td> <label for="LaminaCG5">&nbsp; &nbsp;LAS VOCALES</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG6" id="LaminaCG6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG6</td>                    
                                        <td> <label for="LaminaCG6">&nbsp; &nbsp;NÚMEROS DEL 0 AL 9</label> </td>
                                    </tr>

                                    <tr>
                                        <td> <input  type="number" name="CG7" id="LaminaCG7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG7</td>                    
                                        <td> <label for="LaminaCG7">&nbsp; &nbsp;TABLA DE MULTIPLICAR</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG8" id="LaminaCG8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG8</td>                    
                                        <td> <label for="LaminaCG8">&nbsp; &nbsp;EL ALFABETO EN INGLÉS</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG9" id="LaminaCG9" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG9</td>                    
                                        <td> <label for="LaminaCG9">&nbsp; &nbsp;EL ALFABETO EN ESPAÑOL</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG10" id="LaminaCG10" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CG10</td>                    
                                        <td> <label for="LaminaCG10">&nbsp; &nbsp;MAPAMUNDI POLÍTICO</label> </td>
                                    </tr>
                                    <td class="textC negrita" colspan="3"  style="padding-bottom:0px;"> &nbsp; &nbsp;CARTELES MEDIANOS (45X32 cm.)</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3" style="padding-bottom: 8px;"> &nbsp; &nbsp;COD: 7862102821975</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CM1" id="LaminaCM1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM1</td>                    
                                        <td> <label for="LaminaCM1">&nbsp; &nbsp;SÍMBOLOS PATRIOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="CM2" id="LaminaCM2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM2</td>                    
                                        <td> <label for="LaminaCM2">&nbsp; &nbsp;BANDERA NACIONAL</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CG3" id="LaminaCM3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM3</td>                    
                                        <td> <label for="LaminaCM3">&nbsp; &nbsp;HIMNO NACIONAL</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CM4" id="LaminaCM4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM4</td>                    
                                        <td> <label for="LaminaCM4">&nbsp; &nbsp;ESCUDO NACIONAL</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CM5" id="LaminaCM5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM5</td>                    
                                        <td> <label for="LaminaCM5">&nbsp; &nbsp;LA POLLERA PANAMEÑA</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CM6" id="LaminaCM6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM6</td>                    
                                        <td> <label for="LaminaCM6">&nbsp; &nbsp;EL CANAL DE PANAMÁ</label> </td>
                                    </tr>

                                    <tr>
                                        <td> <input  type="number" name="CM7" id="LaminaCM7" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM7</td>                    
                                        <td> <label for="LaminaCGM7">&nbsp; &nbsp;REGRESO A CLASES 1</label> </td>
                                    </tr>                                        
                                    <tr>
                                        <td> <input  type="number" name="CM8" id="LaminaCM8" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;CM8</td>                    
                                        <td> <label for="LaminaCM8">&nbsp; &nbsp;REGRESO A CLASES 2</label> </td>
                                    </tr>  
                                    <td class="textC negrita" colspan="3" style="padding-bottom:0px;"> &nbsp; &nbsp;LIBROS PARA COLOREAR ¨SOY ARTISTA¨</td> 
                                    </tr>
                                    <tr>                                                               
                                        <td class="textC negrita" colspan="3" style="padding-bottom: 8px;"> &nbsp; &nbsp;COD: 7862102821944</td> 
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC1" id="LaminaLC1" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC1</td>                    
                                        <td> <label for="LaminaLC1">&nbsp; &nbsp;ANIMALES DOMÉSTICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC2" id="LaminaLC2" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC2</td>                    
                                        <td> <label for="LaminaLC2">&nbsp; &nbsp;ANIMALES SALVAJES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC3" id="LaminaLC3" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC3</td>                    
                                        <td> <label for="LaminaLC3">&nbsp; &nbsp;LOS TRANSPORTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC4" id="LaminaLC4" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC4</td>                    
                                        <td> <label for="LaminaLC4">&nbsp; &nbsp;LAS FRUTAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC5" id="LaminaLC5" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC5</td>                    
                                        <td> <label for="LaminaLC5">&nbsp; &nbsp;LA GRANJA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="LC6" id="LaminaLC6" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;LC6</td>                    
                                        <td> <label for="LaminaLC6">&nbsp; &nbsp;OBJETOS DEL ENTORNO</label> </td>
                                    </tr>






                                </table>
                            </div>









                        </div>

                    </div>







            </form>






        </div>
    </body>

</html>