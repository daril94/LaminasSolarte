<?php
session_start();
require_once 'library/connDB.php';

$resultado = consultar("select * from Pedido order by pedidoID desc limit 1");

if (!$resultado) {
    throw new Exception("Error de consulta");
} else {
    while ($filas = $resultado->fetch_assoc()) {
        $ultimaLamina = "$filas[pedidoID]" + 1;
    }
}

function ceros($num) {
    if ($num < 10) {
        $ceros = '00000';
    } else if ($num >= 10 && $num < 100) {
        $ceros = '0000';
    } else if ($num >= 100 && $num < 1000) {
        $ceros = '000';
    } else if ($num >= 1000 && $num < 10000) {
        $ceros = '00';
    } else if ($num >= 10000 && $num < 100000) {
        $ceros = '0';
    }
    return $ceros;
}

$ceros = ceros($ultimaLamina);

$_SESSION['pedido'] = $ceros . $ultimaLamina;
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hoja de Pedidos 2017-2018</title>

    </head>

    <body>   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      


            <!-- Formulario que almacena todos los datos -->        
            <form method="POST" <?php echo "action='?paso=2&hoja=1'" ?>>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018 <?php echo '<br>Pedido: ' . $_SESSION['pedido']; ?>
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>

                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            Por favor completar los datos de facturación 
                                        </p>
                                    </div> 
                                    <div  style="font-size:13px; background-color: whitesmoke; color: #929497; padding:30px" >  
                                        <table class="tablePasos" id="tabla" style="margin: 0 auto; text-align: center; border-collapse: separate;">
                                            <tr class="tdNegro">
                                                <td align="center"> <label for="nombre">&nbsp; &nbsp;Nombre y Apellido</label> </td>                    
                                                <td>&nbsp;&nbsp; </td>
                                                <td align="center"> <label for="email">&nbsp; &nbsp;E-mail</label> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="telefono">&nbsp; &nbsp;Teléfono</label> </td>
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="direccion">&nbsp; &nbsp;Dirección</label> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <label for="ccRuc">&nbsp; &nbsp;CC/RUC</label> </td>
                                            </tr>  
                                            <tr>
                                                <td align="center"> <input  type="text" name="Nombre" id="nombre" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="email" name="Email" id="email" value="" required > </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="number" name="Telefono" id="telefono" value="" min="1" required  > </td>
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="text" name="Direccion" id="direccion" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp;</td>
                                                <td align="center"> <input  type="number" name="CcRuc" id="ccRuc" value="" required > </td>
                                            </tr>  

                                        </table> 
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"></div>

                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV">
                                            TIPO DE PEDIDO 
                                        </p>    
                                    </div>
                                    <div class="lineBlue"></div>

                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            Por favor seleccione el tipo de retiro de su pedido
                                        </p>
                                    </div> 

                                    <div  style="font-size:13px; background-color: whitesmoke; color: black;">   
                                        <table style="margin: 0 auto;">
                                            <tr>
                                                <td align="center"> <label for="almacen">&nbsp; &nbsp;Almacen</label> </td>                    
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label for="domicilio">&nbsp; &nbsp;Domicilio</label> </td>                  
                                            </tr>  
                                            <tr>
                                                <td align="center"> <input  type="radio" name="Entrega" id="almacen" value=""  required> </td>                    
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <input  type="radio" name="Entrega" id="domicilio" value=""  required> </td> 
                                            </tr>  

                                        </table>  
                                    </div>
                                    <div style="padding-top: 50px;"></div>
                                    <input type="submit" value="Seguir al Paso 2"  id="send">
                                </div>

                            </div>

                        </div>

                    </div>








                </div>

            </form>
        </div>
    </body>
</html>
