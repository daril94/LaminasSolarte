<?php
;

require_once '../library/connDB.php';


session_start();

echo 'inicie sesion <br>'  ;
function guardarPedidoUsuario() {
    $sName = $_SESSION['formularioDatos']['Nombre'];
    $sEmail = $_SESSION['formularioDatos']['Email'];
    $iTelefono = $_SESSION['formularioDatos']['Telefono'];
    $sDireccion = $_SESSION['formularioDatos']['Direccion'];
    $iCcRuc = $_SESSION['formularioDatos']['CcRuc'];
    $sRetiro = $_SESSION['formularioDatos']['Entrega'];
    $campos = ('nombreUsuario,emailUsuario,telefonoUsuario,direccionUsuario,ccRucUsuario,entregaUsuario');
    $valores = "'$sName', '$sEmail','$iTelefono','$sDireccion', '$iCcRuc','$sRetiro'";
    insertar('Pedido', $campos, $valores);
}

function guardarPedidoFormulario() {
    $id = $_SESSION['pedido'];
    foreach ($_SESSION['formularioHojas'] as $campo => $a) {
        //$i++;
        if ($a >= 25) {
            $campos = ('pedidoID,codigo,cantidad');
            $valores = "'$id', '$campo','$a'";
            insertar('laminasPedido', $campos, $valores);
        }
    }
}

function guardarSumatoria() {
    $id = $_SESSION['pedido'];

    if ($_SESSION['Laminas'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','Laminas', '$_SESSION[Laminas]'";
        insertar('sumatorioPedido', $campos, $valores);
    }
    if ($_SESSION['LibrosparaColorear'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','LibrosparaColorear', '$_SESSION[LibrosparaColorear]'";
        insertar('sumatorioPedido', $campos, $valores);
    }

    if ($_SESSION['TablaElementos'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','TablaElementos', '$_SESSION[TablaElementos]'";
        insertar('sumatorioPedido', $campos, $valores);
    }

    if ($_SESSION['Cartilla4Operaciones'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','Cartilla4Operaciones', '$_SESSION[Cartilla4Operaciones]'";
        insertar('sumatorioPedido', $campos, $valores);
    }

    if ($_SESSION['Armablesparamaquetas'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','Armablesparamaquetas', '$_SESSION[Armablesparamaquetas]'";
        insertar('sumatorioPedido', $campos, $valores);
    }



    if ($_SESSION['CartelesMedianos'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','CartelesMedianos', '$_SESSION[CartelesMedianos]'";
        insertar('sumatorioPedido', $campos, $valores);
    }

    if ($_SESSION['Croquis'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','Croquis', '$_SESSION[Croquis]'";
        insertar('sumatorioPedido', $campos, $valores);
    }

    if ($_SESSION['CartelesGrandes'] >= 25) {
        $campos = ('pedidoID,nombre,cantidad');
        $valores = "'$id','CartelesGrandes', '$_SESSION[CartelesGrandes]'";
        insertar('sumatorioPedido', $campos, $valores);
    }
}

\guardarPedidoUsuario();
\guardarPedidoFormulario();
\guardarSumatoria();

session_destroy();

header("Location:../index.php");
