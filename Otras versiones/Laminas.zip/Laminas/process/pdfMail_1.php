<?php


require_once 'mostrarDatos.php';
require('../PDF/fpdf.php');
session_start();
ob_start();
mostrarDatos(1);
$count = 0;
$datos = ob_get_contents();
$data = ['1=50','10=50','12=50','13=50','60=25',' 61=25', '62=25','65=25','68=25','69=25','70=25','71=25','75=25', ];
ob_end_clean();
$pdf = new FPDF();
$pdf->SetTopMargin(0);
$pdf->SetLeftMargin(0);
$pdf->SetRightMargin(0);
$pdf->AddPage();

$pdf->SetFont('Helvetica', 'B', 14);

$pdf->SetFillColor(0, 103, 188);
$pdf->SetTextColor(255);

$pdf->Cell(0, 25, utf8_decode('Número de pedido'), 0, 0, 'C', true);
$pdf->Ln();
$pdf->Cell(0, -12, utf8_decode('000012'), 0, 0, 'C');

$pdf->SetY(50);
$pdf->SetLeftMargin(20);
$pdf->SetTextColor(0);

$pdf->Cell(0, 8, utf8_decode('Nombre: Daril Avila'), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Email: daril_1994@gmail.com'), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Telefono: 0987055269'), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Dirección: Av Teniente Hugo Ortiz'), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Cc-Ruc: 0804403004'), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Entrega: Domicilio'), 0, 0, 'L');
$pdf->SetLeftMargin(0);
$pdf->Ln();
$pdf->Ln();


$pdf->SetLeftMargin(0);
$pdf->Cell(0, 1, utf8_decode(''), 0, 0, 'L', true);
$pdf->Ln();
$pdf->SetTextColor(146, 146, 146);
$pdf->Cell(0, 10, utf8_decode('Pedido Realizado'), 0, 0, 'C');
$pdf->Ln();
$pdf->Cell(0, 1, utf8_decode(''), 0, 0, 'L', true);


$pdf->Ln();
$pdf->Ln();
$pdf->SetTextColor(0, 103, 188);
$pdf->Cell(0, 10, utf8_decode('Número de lámina = cantidad de láminas'), 0, 0, 'C');

$pdf->Ln();
$pdf->Ln();

$pdf->SetTextColor(0);
foreach ($data as $ds) {
    $pdf->SetLeftMargin(20);
    $count++;
    $pdf->Cell(50, 10, $ds);
//echo $count;    
    if ($count % 4 == 0) {
        $pdf->Ln();
    }
}




$pdf->Ln();
$pdf->Output('../pdfGenerado/Pedido000012.pdf', 'F');
exit;

require_once 'email.php';

