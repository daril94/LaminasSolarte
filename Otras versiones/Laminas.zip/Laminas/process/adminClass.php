<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of adminClass
 *
 * @author FAMILIA
 */
class adminClass {

    private $pedido;
    private $usuario;
    private $fecha;

    public function setPedido($ped, $usu, $fecha) {
        $this->pedido = $ped;
        $this->usuario = $usu;
        $this->fecha = $fecha;
    }
    
    public function addPedido (){
        echo " <div class='col-md-12'>";        
        echo "</div>";
        
    }
    

}
