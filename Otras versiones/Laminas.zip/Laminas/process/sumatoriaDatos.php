<?php

//session_start();
$_SESSION['Laminas'] = 0;
$_SESSION['Croquis'] = 0;
$_SESSION['LibrosparaColorear'] = 0;
$_SESSION['TablaElementos'] = 0;
$_SESSION['Cartilla4Operaciones'] = 0;
$_SESSION['Armablesparamaquetas'] = 0;
$_SESSION['CartelesMedianos'] = 0;
$_SESSION['CartelesGrandes'] = 0;

function sumatoria() {
    $iLaminas = 0;
    $iCartelesGrandes = 0;
    $iCartelesMedianos = 0;
    $iCroquis = 0;
    $iTablaElementos = 0;
    $iCartilla4Operaciones = 0;
    $iArmablesparamaquetas = 0;
    $iLibrosparacolorear = 0;

    foreach ($_SESSION['formularioHojas'] as $campo => $a) {
        if ($a >= 25) {
            if ($campo[0] == 'C' && $campo[1] == 'Q') {
                $_SESSION['Croquis'] = $iCroquis += $a;
            } else if ($campo[0] == 'L' && $campo[1] == 'C') {
                $_SESSION['LibrosparaColorear'] = $iLibrosparacolorear += $a;
            } else if ($campo[0] == 'T' && $campo[1] == 'P') {
                $_SESSION['TablaElementos'] = $iTablaElementos += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'B') {
                $_SESSION['Cartilla4Operaciones'] = $iCartilla4Operaciones += $a;
            } else if ($campo[0] == 'A') {
                $_SESSION['Armablesparamaquetas'] = $iArmablesparamaquetas += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'M') {
                $_SESSION['CartelesMedianos'] = $iCartelesMedianos += $a;
            } else if ($campo[0] == 'C' && $campo[1] == 'G') {
                $_SESSION['CartelesGrandes'] = $iCartelesGrandes += $a;
            } else {
                $_SESSION['Laminas'] = $iLaminas += $a;
            }
        }
    }
}
