<?php

session_start();
require_once 'mostrarDatos.php';
require('../PDF/fpdf.php');

ob_start();
mostrarDatos(1);
$count = 0;
$datos = ob_get_contents();
$data = explode(";", $datos);
ob_end_clean();
$pdf = new FPDF();
$pdf->SetLeftMargin(0);
$pdf->SetRightMargin(0);
$pdf->AddPage();

$pdf->SetFont('Helvetica', 'B', 14);

$pdf->SetFillColor(0,103,188);
$pdf->SetTextColor(255);

$pdf->Cell(0, 25, utf8_decode('Número de pedido'), 0, 0, 'C', true);
$pdf->Ln();
$pdf->Cell(0, -5, utf8_decode($_SESSION['pedido']), 0, 0, 'C');

$pdf->SetY(50);
$pdf->SetLeftMargin(20);
$pdf->SetTextColor(0);

$pdf->Cell(0, 8, utf8_decode('Nombre: ' . $_SESSION['formularioDatos']['Nombre']), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Email: ' . $_SESSION['formularioDatos']['Email']), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Telefono: ' . $_SESSION['formularioDatos']['Telefono']), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Direccion: ' . $_SESSION['formularioDatos']['Direccion']), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Cedula-Ruc: ' . $_SESSION['formularioDatos']['CcRuc']), 0, 0, 'L');
$pdf->Ln();
$pdf->Cell(0, 8, utf8_decode('Tipo de Entrega: ' . $_SESSION['formularioDatos']['Entrega']), 0, 0, 'L');
$pdf->SetLeftMargin(0);
$pdf->Ln();
$pdf->Ln();


$pdf->SetLeftMargin(0);
$pdf->Cell(0,1, utf8_decode(''), 0, 0, 'L', true);
$pdf->Ln();
$pdf->SetTextColor(146,146,146);
$pdf->Cell(0, 10, utf8_decode('Pedido Realizado'), 0, 0, 'C');
$pdf->Ln();
$pdf->Cell(0,1, utf8_decode(''), 0, 0, 'L', true);


$pdf->Ln();
$pdf->Ln();
$pdf->SetTextColor(0,103,188);
$pdf->Cell(0, 10, utf8_decode('Número de lámina = cantidad de láminas'), 0, 0, 'C');

$pdf->Ln();
$pdf->Ln();

$pdf->SetTextColor(0);
foreach ($data as $ds) {
    $pdf->SetLeftMargin(20);
    $count++;
    $pdf->Cell(50, 10, $ds);
//echo $count;    
    if ($count % 4 == 0) {
        $pdf->Ln();
    }
}




$pdf->Ln();

$pdf->Output('Pedido' . $_SESSION['pedido'] . '.pdf', 'D');
exit;


