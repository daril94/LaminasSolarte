<?php

session_start();

function guardarDatos($pasos) {
    if ($pasos == 1) {
        foreach ($_POST as $campo => $valor) {
            //$j++;
            $_SESSION['formularioDatos'][$campo] = $valor;
        }
    }
    if ($pasos == 2) {
        foreach ($_POST as $campo => $valor) {
            // $j++;
            if ($valor != "" && isset($valor)) {
                $_SESSION['formularioHojas'][$campo] = $valor;
            }
        }
    }
}
