<?php

session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

///Crear una instancia de PHPMailer
$mail = new PHPMailer();
//Definir que vamos a usar SMTP
$mail->IsSMTP();
//Esto es para activar el modo depuración. En entorno de pruebas lo mejor es 2, en producción siempre 0
// 0 = off (producción)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 0;
//Ahora definimos gmail como servidor que aloja nuestro SMTP
$mail->Host = 'smtp.gmail.com';
//El puerto será el 587 ya que usamos encriptación TLS
$mail->Port = 25;
//Definmos la seguridad como TLS
$mail->SMTPSecure = 'tls';
//Tenemos que usar gmail autenticados, así que esto a TRUE
$mail->SMTPAuth = true;
//Definimos la cuenta que vamos a usar. Dirección completa de la misma
$mail->Username = "aviladaril@gmail.com";
//Introducimos nuestra contraseña de gmail
$mail->Password = "darilvago1216";
//Definimos el remitente (dirección y, opcionalmente, nombre)
$mail->SetFrom('ventasecuador@laminassolarte.com', 'ventasecuador@laminassolarte.com');
//Esta línea es por si queréis enviar copia a alguien (dirección y, opcionalmente, nombre)
$mail->AddReplyTo('replyto@correoquesea.com','El de la réplica');
//Y, ahora sí, definimos el destinatario (dirección y, opcionalmente, nombre)
$mail->AddAddress('daril_1994@hotmail.com', 'Daril Avila');
$mail->AddAddress('ventasecuador@laminassolarte.com', 'Ventas Ecuador');
$mail->addBCC('carlyandy1994@gmail.com', 'Carla Naranjo');
$mail->addCC('carlyandy1994@gmail.com');
//Definimos el tema del email
$mail->Subject = 'Prueba Pedido #000012';
$mail->addAttachment('../pdfGenerado/Pedido000012.pdf');
//Para enviar un correo formateado en HTML lo cargamos con la siguiente función. Si no, puedes meterle directamente una cadena de texto.
//$mail->MsgHTML(file_get_contents('correomaquetado.html'), dirname(ruta_al_archivo));
//Y por si nos bloquean el contenido HTML (algunos correos lo hacen por seguridad) una versión alternativa en texto plano (también será válida para lectores de pantalla)
$mail->AltBody = 'Prueba Pedido';
$mail->Body = ' Prueba Pedido #000012   Pedido por : Daril Avila, aviladaril@gmail.com';
//Enviamos el correo
if (!$mail->Send()) {
    echo "Error: " . $mail->ErrorInfo;
} else {
    echo "Enviado!";
        header("Location:../final.php");
}



