<?php

require_once '../library/connDB.php';
session_start();

if (isset($_POST['emailAdmin']) && isset($_POST['passAdmin'])) {

    $emailAdmin = $_POST['emailAdmin'];
    $passAdmin = $_POST['passAdmin'];

    echo'Recibido: ' . $emailAdmin . ' ' . $passAdmin . '<br>';
    $resultado = consultar("select * from Administrador where userAdmin= '$emailAdmin'");
    if (!$resultado) {
        throw new Exception("Error de consulta");
    } else {
        while ($filas = $resultado->fetch_assoc()) {
            echo 'base: ' . $filas['userAdmin'] . ' ' . $filas['passAdmin'];
            if ($passAdmin == $filas['passAdmin']) {
                echo 'si <br>';
                $_SESSION['admin'] = $filas['userAdmin'];
                echo $_SESSION['pass'];

                header('Location:../admin.php');
            } else
                echo '<br> no';
        }
    }
}


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

