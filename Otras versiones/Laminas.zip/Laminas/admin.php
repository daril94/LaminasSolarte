<?php
if (!isset($_SESSION['admin'])) {
    // header('Location: inicioSesion.php');
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hoja de Pedidos 2017-2018</title> 
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/stylesPan.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/laminas.js" type="text/javascript"></script>
    </head>
    <body style="background-image: url(assets/img/fondoForm1.jpg ); background-size:cover;" onload="cambiarHoja(); cambiarDivPasos()">             
        <div id="padre">      


            <!-- Formulario que almacena todos los datos -->        
            <form method="POST" <?php echo "action='?paso=2&hoja=1'" ?>>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            Administracion
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>


                                    <div  style="font-size:13px; background-color: whitesmoke; color: #929497;">  
                                        <table id="tabla" style="margin: 0 auto; text-align: left">
                                            <tr>
                                                <th>
                                                    <a href='#' style="color:black">Pedido</a>
                                                </th>

                                                <th>
                                                    <a href='#' style="color:black"> Datos</a>
                                                </th>
                                            </tr>


                                        </table> 
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <?php
                                    require_once 'library/connDB.php';

                                    $resultado = consultar("select * from pedido");
                                    if (!$resultado) {
                                        throw new Exception("Error de consulta");
                                    } else {
                                        while ($filas = $resultado->fetch_assoc()) {
                                            echo'<table>';
                                            echo'<tr>';
                                            echo'<td>';
                                            $filas['pedidoID'];
                                            echo'</td>';
                                            echo'</td>';
                                            echo'</table>';
                                        }
                                    }
                                    ?>


                                </div>

                            </div>

                        </div>








                    </div>

            </form>
        </div> 



    </body>
</html>
