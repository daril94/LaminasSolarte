<?php
require_once 'process/guardarDatos.php';
require_once 'process/sumatoriaDatos.php';
guardarDatos(2);
sumatoria();
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hoja de Pedidos 2017-2018</title>

    </head>
    <body style="background-image: url(img/fondoForm1.jpg ); background-size:cover;">           
        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">   
            <!-- Formulario que almacena todos los datos -->        
            <form method="post" action="?paso=4">                
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:12px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018 
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>                                    
                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            A continuación se muestra el TOTAL de su pedido
                                        </p>
                                    </div> 
                                    <div  style="font-size:13px; background-color: whitesmoke; color: #929497; padding: 20px">  
                                        <table id="tabla" align="center">
                                            <tr class="tdNegro">
                                                <td align="center"> <label >Láminas</label> </td>
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label >Croquis</label> </td> 
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label >Tabla de elementos</label> </td>
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label >Cartilla de las 4 operaciones</label> </td>  
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label >Armables para maquetas</label> </td> 
                                            </tr>  
                                            <tr>
                                                <td align="center"> <?php echo $_SESSION['Laminas'] ?></td>  
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <?php echo $_SESSION['Croquis'] ?></td>  
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <?php echo $_SESSION['TablaElementos'] ?>  </td>
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center">  <?php echo $_SESSION['Cartilla4Operaciones'] ?></td> 
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <?php echo $_SESSION['Armablesparamaquetas'] ?> </td> 
                                            </tr> 
                                        </table> 
                                    </div>

                                    <div  style="font-size:13px; background-color: whitesmoke; color: #929497;padding-bottom: 30px">  
                                        <table id="tabla" align="center" >
                                            <tr class="tdNegro">                                                           
                                                <td align="center"> <label>Carteles grandes(64x45) cm</label> </td> 
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center"> <label>Carteles medianos (45x32) cm</label> </td>
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center" ><label>Libros para colorear</label> </td>  
                                            </tr>  
                                            <tr>                                                               
                                                <td align="center">  <?php echo $_SESSION['CartelesGrandes'] ?>   </td>   
                                                <td>&nbsp;&nbsp; &nbsp; &nbsp;</td>
                                                <td align="center">  <?php echo $_SESSION['CartelesMedianos'] ?> </td>
                                                <td>&nbsp; &nbsp; &nbsp;&nbsp;</td>
                                                <td align="center"> <?php echo $_SESSION['LibrosparaColorear'] ?>  </td>                   
                                            </tr>  

                                        </table>
                                    </div>
                                    <input type="submit" value="Seguir al Paso 4"  name="enviar" id="send">
                                </div>
                            </div>
                        </div>
                    </div>
            </form>






        </div>


    </body>
</html>
