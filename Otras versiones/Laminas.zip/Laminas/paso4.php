
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hoja de Pedidos 2017-2018</title>

    </head>   
    <body>   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      


            <!-- Formulario que almacena todos los datos -->        
            <form method="post" action="">

                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <img src="assets/img/pasoFinal.jpg"  alt="Paso Final">

                                </div> 
                                <input type="button" value="Generar PDF"  onclick="location = 'process/pdf.php'" name="" id="send2">
                                <input type="button" value="Terminar"  name="" id="send" onclick="location = 'process/pdfMail.php'">




                            </div>

                        </div>

                    </div>
                </div>

            </form>






        </div>


    </body>
</html>
