<?php

?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>HOJA DE PEDIDO</title>

    </head>
    <body style="background-image: url(img/fondoForm1.jpg ); background-size:cover;">   

        <!-- Este div llamado padre, simplemente tiene un ancho y alto del 100% -->
        <div id="padre">      




            <!-- Formulario que almacena todos los datos -->        
            <form method="post" name="form3">

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <!-- Parte superior del formulario--> 
                            <div class="row">
                                <div class="col-md-12">                                       
                                    <div class="lineOrangeTitle" style="font-size:12px; background-color: black; color: white">
                                        <p class="alignV"> 
                                            HOJA DE PEDIDO 2018  <?php echo 'Pedido:' . $_SESSION['pedido']; ?> 
                                        </p>
                                    </div>     
                                    <div class="lineOrangeTitle" style="font-size:13px; background-color: whitesmoke; color: black;">
                                        <p class="alignV"> 
                                            Educamos a través del arte
                                        </p>
                                    </div>
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"> </div>

                                    <div class="lineOrangeTitle">
                                        <p class="alignV" style="font-size:13px; background-color: whitesmoke; color: #929497;"> 
                                            Por favor haga su pedido. No olvide seleccionar mínimo 25 UNIDADES por tema  
                                        </p>
                                    </div> 
                                    <!--Genera una linea azul--> 
                                    <div class="lineBlue"></div>
                                </div>

                            </div>

                            <!-- Se crean 3 tablas diferentes para crear el formulario --> 
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">          
                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita"  colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG280" id="LaminaSG280" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;280 </td>                    
                                        <td> <label for="LaminaSG280">&nbsp; &nbsp;ANIMALES CARNÍVOROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG281" id="LaminaSG281" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;281 </td>                    
                                        <td> <label for="LaminaSG281">&nbsp; &nbsp;ANIMALES HERVÍBOROS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG282" id="LaminaSG282" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;282 </td>                    
                                        <td> <label for="LaminaSG282">&nbsp; &nbsp;ANIMALES OMNÍVOROS</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG283" id="LaminaSG283" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;283 </td>                    
                                        <td> <label for="LaminaSG283">&nbsp; &nbsp;EL PLANISFERIO - POLÍTICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG284" id="LaminaSG284" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;284 </td>                    
                                        <td> <label for="LaminaSG284">&nbsp; &nbsp;EL ALCOHOLISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG285" id="LaminaSG285" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;285 </td>                    
                                        <td> <label for="LaminaSG285">&nbsp; &nbsp;EL TABAQUISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG286" id="LaminaSG286" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;286 </td>                    
                                        <td> <label for="LaminaSG286">&nbsp; &nbsp;LAS MONOCOTILEDÓNEAS</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG287" id="LaminaSG257" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;287 </td>                    
                                        <td> <label for="LaminaSG287">&nbsp; &nbsp;LAS DICOTILEDÓNEAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG288" id="LaminaSG258" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;288 </td>                    
                                        <td> <label for="LaminaSG288">&nbsp; &nbsp;EL ÁTOMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG289" id="LaminaSG289" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;289 </td>                    
                                        <td> <label for="LaminaSG289">&nbsp; &nbsp;OCEANÍA FÍSICO Y POLÍTICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG290" id="LaminaSG290" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;290 </td>                    
                                        <td> <label for="LaminaSG290">&nbsp; &nbsp;AMÉR. CENTRAL FÍSIC. Y POLÍ.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG291" id="LaminaSG291" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;291 </td>                    
                                        <td> <label for="LaminaSG291">&nbsp; &nbsp;RENACIMIENTO N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG292" id="LaminaSG292" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;292 </td>                    
                                        <td> <label for="LaminaSG292">&nbsp; &nbsp;RENACIMIENTO N°2</label> </td>
                                    </tr> <tr>
                                        <td> <input  type="number" name="SG293" id="LaminaSG293" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;293 </td>                    
                                        <td> <label for="LaminaSG293">&nbsp; &nbsp;6 SIST.DEL CUERPO HUMANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG294" id="LaminaSG294" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;294 </td>                    
                                        <td> <label for="LaminaSG294">&nbsp; &nbsp;EL ESQUELETO HUMANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG295" id="LaminaSG295" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;295 </td>                    
                                        <td> <label for="LaminaSG295">&nbsp; &nbsp;7 NUEVAS MARAVI. MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG296" id="LaminaSG296" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;296 </td>                    
                                        <td> <label for="LaminaSG296">&nbsp; &nbsp;CLIMAS DEL MUNDO</label> </td>
                                    </tr> 
                                    <tr>
                                        <td> <input  type="number" name="SG297" id="LaminaSG297" value="" min="25" max="9999" step="25"  > </td>                    
                                        <td> &nbsp; &nbsp;297 </td>                    
                                        <td> <label for="LaminaSG297">&nbsp; &nbsp;DISTRIBUCIÓN DE LA FAUNA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG298" id="LaminaSG298" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;298 </td>                    
                                        <td> <label for="LaminaSG298">&nbsp; &nbsp;DISTRIBUCIÓN DE LA FLORA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG299" id="LaminaSG299" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;299 </td>                    
                                        <td> <label for="LaminaSG299">&nbsp; &nbsp;LA MENSTRUACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG300" id="LaminaSG300" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;300 </td>                    
                                        <td> <label for="LaminaSG300">&nbsp; &nbsp;MAPA ECONÓMICO AMER.SUR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG301" id="LaminaSG301" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;301 </td>                    
                                        <td> <label for="LaminaSG301">&nbsp; &nbsp;MAP.ECONÓMICO. A.NORTE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG302" id="LaminaSG302" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;302 </td>                    
                                        <td> <label for="LaminaSG302">&nbsp; &nbsp;MAP.ECONÓMIC.A.CENTRAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG303" id="LaminaSG303" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;303 </td>                    
                                        <td> <label for="LaminaSG303">&nbsp; &nbsp;MAPA ECONÓMICO ÁFRICAN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG304" id="LaminaSG304" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;304 </td>                    
                                        <td> <label for="LaminaSG304">&nbsp; &nbsp;MAPA ECONÓMICO EUROPA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG305" id="LaminaSG305" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;305 </td>                    
                                        <td> <label for="LaminaSG305">&nbsp; &nbsp;MAPA ECONÓMICO ASIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG306" id="LaminaSG306" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;306 </td>                    
                                        <td> <label for="LaminaSG306">&nbsp; &nbsp;MAPA ECONÓMICO OCEANÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG307" id="LaminaSG307" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;307 </td>                    
                                        <td> <label for="LaminaSG307">&nbsp; &nbsp;ANIMALES EXTINCIÓN MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG308" id="LaminaSG308" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;308 </td>                    
                                        <td> <label for="LaminaSG308">&nbsp; &nbsp;LOS ANTICONCEPTIVOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG309" id="LaminaSG309" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;309 </td>                    
                                        <td> <label for="LaminaSG309">&nbsp; &nbsp;EL ABORTO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG310" id="LaminaSG310" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;310 </td>                    
                                        <td> <label for="LaminaSG310">&nbsp; &nbsp;TRANSPORTES MODERNOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG311" id="LaminaSG311" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;311 </td>                    
                                        <td> <label for="LaminaSG311">&nbsp; &nbsp;PLANTAS INTERIOR DE HOJA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG312" id="LaminaSG312" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;312 </td>                    
                                        <td> <label for="LaminaSG312">&nbsp; &nbsp;PLANTAS INTERIOR DE FLOR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG313" id="LaminaSG313" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;313 </td>                    
                                        <td> <label for="LaminaSG313">&nbsp; &nbsp;VIAS DE COMUNICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG314" id="LaminaSG314" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;314 </td>                    
                                        <td> <label for="LaminaSG314">&nbsp; &nbsp;ENFERMEDADES INFECCIOSAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG315" id="LaminaSG315" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;315 </td>                    
                                        <td> <label for="LaminaSG315">&nbsp; &nbsp;LA MATERIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG316" id="LaminaSG316" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;316 </td>                    
                                        <td> <label for="LaminaSG316">&nbsp; &nbsp;REVOLUCIÓN INDUSTRIAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG317" id="LaminaSG317" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;317 </td>                    
                                        <td> <label for="LaminaSG317">&nbsp; &nbsp;DESARROLLO HUMANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG318" id="LaminaSG318" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;318 </td>                    
                                        <td> <label for="LaminaSG318">&nbsp; &nbsp;LOS DIENTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG319" id="LaminaSG319" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;319 </td>                    
                                        <td> <label for="LaminaSG319">&nbsp; &nbsp;SISTEMA LINFÁTICO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG320" id="LaminaSG320" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;320 </td>                    
                                        <td> <label for="LaminaSG320"> &nbsp; &nbsp;EL VIACRUSIS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG321" id="LaminaSG321" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;321 </td>                    
                                        <td> <label for="LaminaSG321">&nbsp; &nbsp;DEBERES DEL NIÑO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG322" id="LaminaSG322" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;322 </td>                    
                                        <td> <label for="LaminaSG322">&nbsp; &nbsp;LA ENERGÍA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG323" id="LaminaSG323" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;323 </td>                    
                                        <td> <label for="LaminaSG323">&nbsp; &nbsp;LA LUZ</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG324" id="LaminaSG324" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;324 </td>                    
                                        <td> <label for="LaminaSG324">&nbsp; &nbsp;CALOR Y TEMPERATURA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG325" id="LaminaSG325" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;325 </td>                    
                                        <td> <label for="LaminaSG325">&nbsp; &nbsp;ORIGEN HOMBRE AMERICANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG306" id="LaminaSG326" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;326 </td>                    
                                        <td> <label for="LaminaSG326">&nbsp; &nbsp;CADENAS ALIMENTICIAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG307" id="LaminaSG327" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;327 </td>                    
                                        <td> <label for="LaminaSG327">&nbsp; &nbsp;LA DESNUTRICIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG328" id="LaminaSG328" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;328 </td>                    
                                        <td> <label for="LaminaSG328">&nbsp; &nbsp;LOS CARBOHIDRATOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG329" id="LaminaSG329" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;329 </td>                    
                                        <td> <label for="LaminaSG329">&nbsp; &nbsp;LOS LÍPIDOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG330" id="LaminaSG330" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;330 </td>                    
                                        <td> <label for="LaminaSG330">&nbsp; &nbsp;LAS PROTEÍNAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG331" id="LaminaSG331" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;331 </td>                    
                                        <td> <label for="LaminaSG331">&nbsp; &nbsp;LOS MINERALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG332" id="LaminaSG332" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;332 </td>                    
                                        <td> <label for="LaminaSG332">&nbsp; &nbsp;LAS VITAMINAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG333" id="LaminaSG333" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;333 </td>                    
                                        <td> <label for="LaminaSG333">&nbsp; &nbsp;TIPOS DE VITAMINAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG334" id="LaminaSG334" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;334 </td>                    
                                        <td> <label for="LaminaSG334">&nbsp; &nbsp;LA NUTRICIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG335" id="LaminaSG335" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;335 </td>                    
                                        <td> <label for="LaminaSG335">&nbsp; &nbsp;LAS ESPONJAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG336" id="LaminaSG336" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;336 </td>                    
                                        <td> <label for="LaminaSG336">&nbsp; &nbsp;LOS CELENTÉREOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG337" id="LaminaSG337" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;337 </td>                    
                                        <td> <label for="LaminaSG337">&nbsp; &nbsp;CALENTAMIENTO GLOBAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG338" id="LaminaSG338" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;338 </td>                    
                                        <td> <label for="LaminaSG338">&nbsp; &nbsp;HIGIENE ESCOLAR Nº2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG339" id="LaminaSG339" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;339 </td>                    
                                        <td> <label for="LaminaSG339">&nbsp; &nbsp;LOS ARTRÓPODOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG340" id="LaminaSG340" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;340 </td>                    
                                        <td> <label for="LaminaSG340">&nbsp; &nbsp;EL SIDA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG341" id="LaminaSG341" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;341 </td>                    
                                        <td> <label for="LaminaSG341">&nbsp; &nbsp;LA NATACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG342" id="LaminaSG342" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;342 </td>                    
                                        <td> <label for="LaminaSG342">&nbsp; &nbsp;EL PETRÓLEO</label> </td>
                                    </tr>


                                </table>

                            </div>

                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">             

                                <table class="textI">
                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG343" id="LaminaSG343" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;343 </td>                    
                                        <td> <label for="LaminaSG343">&nbsp; &nbsp;CUIDADOS MEDIO AMBIENTE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG344" id="LaminaSG344" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;344 </td>                    
                                        <td> <label for="LaminaSG344">&nbsp; &nbsp;EL ATLETISMO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG335" id="LaminaSG345" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;345 </td>                    
                                        <td> <label for="LaminaSG345">&nbsp; &nbsp;PLATELMINTOS Y NEMÁTODOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG346" id="LaminaSG346" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;346 </td>                    
                                        <td> <label for="LaminaSG346">&nbsp; &nbsp;LOS EQUINODERMOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG347" id="LaminaSG347" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;347 </td>                    
                                        <td> <label for="LaminaSG347">&nbsp; &nbsp;TIPOS DE GANADO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG338" id="LaminaSG348" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;348 </td>                    
                                        <td> <label for="LaminaSG348">&nbsp; &nbsp;AGRICULTURA N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG349" id="LaminaSG349" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;349 </td>                    
                                        <td> <label for="LaminaSG349">&nbsp; &nbsp;AGRICULTURA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG350" id="LaminaSG350" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;350 </td>                    
                                        <td> <label for="LaminaSG350">&nbsp; &nbsp;CLASES DE SUELOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG351" id="LaminaSG351" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;351 </td>                    
                                        <td> <label for="LaminaSG351">&nbsp; &nbsp;MEDIOS COMU. MODERNOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG352" id="LaminaSG352" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;352 </td>                    
                                        <td> <label for="LaminaSG352">&nbsp; &nbsp;LAS 3 COMIDAS BÁSICAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG353" id="LaminaSG353" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;353 </td>                    
                                        <td> <label for="LaminaSG353">&nbsp; &nbsp;CULTURA ROMANA N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG354" id="LaminaSG354" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;354 </td>                    
                                        <td> <label for="LaminaSG354">&nbsp; &nbsp;CULTURA ROMANA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG355" id="LaminaSG355" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;355 </td>                    
                                        <td> <label for="LaminaSG355">&nbsp; &nbsp;CULTURA GRIEGA N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG356" id="LaminaSG356" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;356 </td>                    
                                        <td> <label for="LaminaSG356">&nbsp; &nbsp;REVOLUCIÓN FRANCESA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG357" id="LaminaSG357" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;357 </td>                    
                                        <td> <label for="LaminaSG357">&nbsp; &nbsp;REPRODUCCIÓN ASEXUAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG358" id="LaminaSG358" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;358 </td>                    
                                        <td> <label for="LaminaSG358">&nbsp; &nbsp;REPRODUCCIÓN SEXUAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG359" id="LaminaSG359" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;359 </td>                    
                                        <td> <label for="LaminaSG359">&nbsp; &nbsp;COMUNI. URBANA Y RURAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG360" id="LaminaSG360" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;360 </td>                    
                                        <td> <label for="LaminaSG360">&nbsp; &nbsp;HUSOS HORARIOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG361" id="LaminaSG361" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;361 </td>                    
                                        <td> <label for="LaminaSG361">&nbsp; &nbsp;CLASIFICACIÓN DE PLANTAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG362" id="LaminaSG362" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;362 </td>                    
                                        <td> <label for="LaminaSG362">&nbsp; &nbsp;PLANTAS POR SU UTILIDAD</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG363" id="LaminaSG363" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;363 </td>                    
                                        <td> <label for="LaminaSG363">&nbsp; &nbsp;CLASIFICA. REINO ANIMAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG364" id="LaminaSG364" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;364 </td>                    
                                        <td> <label for="LaminaSG364">&nbsp; &nbsp;MAQUI. SIMPLES Y COMPU.N</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG365" id="LaminaSG365" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;365 </td>                    
                                        <td> <label for="LaminaSG365">&nbsp; &nbsp;ÓRGANOS CUERPO HUMANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG366" id="LaminaSG366" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;366 </td>                    
                                        <td> <label for="LaminaSG356">&nbsp; &nbsp;LAS ESTRELLAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG367" id="LaminaSG367" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;367 </td>                    
                                        <td> <label for="LaminaSG367">&nbsp; &nbsp;LAS CONSTELACIONES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG358" id="LaminaSG368" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;368 </td>                    
                                        <td> <label for="LaminaSG358">&nbsp; &nbsp;GALAXIAS Y NEBULOSAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG359" id="LaminaSG369" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;369 </td>                    
                                        <td> <label for="LaminaSG359">&nbsp; &nbsp;ERA PALEOLÍTICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG370" id="LaminaSG370" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;370 </td>                    
                                        <td> <label for="LaminaSG370">&nbsp; &nbsp;ERA NEOLÍTICA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG371" id="LaminaSG371" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;371 </td>                    
                                        <td> <label for="LaminaSG371">&nbsp; &nbsp;EDAD DE LOS METALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG372" id="LaminaSG372" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;372 </td>                    
                                        <td> <label for="LaminaSG372">&nbsp; &nbsp;LA ATMÓSFERA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG373" id="LaminaSG373" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;373 </td>                    
                                        <td> <label for="LaminaSG373">&nbsp; &nbsp;LOS SATÉLITES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG374" id="LaminaSG374" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;374 </td>                    
                                        <td> <label for="LaminaSG374">&nbsp; &nbsp;LA EDAD MEDIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG375" id="LaminaSG375" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;375 </td>                    
                                        <td> <label for="LaminaSG375">&nbsp; &nbsp;LA ELECTRICIDAD</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG376" id="LaminaSG376" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;376</td>                    
                                        <td> <label for="LaminaSG376">&nbsp; &nbsp;CINCO VOCALES JUNTAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG377" id="LaminaSG377" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;377 </td>                    
                                        <td> <label for="LaminaSG377">&nbsp; &nbsp;PLANTAS VENENOSAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG378" id="LaminaSG378" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;378 </td>                    
                                        <td> <label for="LaminaSG378">&nbsp; &nbsp;PLANTAS AROMÁTICAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG379" id="LaminaSG379" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;379 </td>                    
                                        <td> <label for="LaminaSG379">&nbsp; &nbsp;INSECT.PERJ.AGRICULTURA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG380" id="LaminaSG380" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;380 </td>                    
                                        <td> <label for="LaminaSG380">&nbsp; &nbsp;ÚTILES Y MATERIALES OFICINA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG381" id="LaminaSG381" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;381 </td>                    
                                        <td> <label for="LaminaSG381">&nbsp; &nbsp;EQUIPOS Y MUEBLES OFICINA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG382" id="LaminaSG382" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;382 </td>                    
                                        <td> <label for="LaminaSG382">&nbsp; &nbsp;PARÁBOLAS DE JESÚS N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG383" id="LaminaSG383" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;383 </td>                    
                                        <td> <label for="LaminaSG383">&nbsp; &nbsp;PARÁBOLAS DE JESÚS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG384" id="LaminaSG384" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;384 </td>                    
                                        <td> <label for="LaminaSG384">&nbsp; &nbsp;LOS DOCE APÓSTOLES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG385" id="LaminaSG385" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;385 </td>                    
                                        <td> <label for="LaminaSG385">&nbsp; &nbsp;LA BIBLIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG386" id="LaminaSG386" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;386</td>                    
                                        <td> <label for="LaminaSG386">&nbsp; &nbsp;EL HUERTO ESCOLAR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG387" id="LaminaSG387" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;387 </td>                    
                                        <td> <label for="LaminaSG387">&nbsp; &nbsp;SIETE PECADOS CAPITALES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG388" id="LaminaSG388" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;388 </td>                    
                                        <td> <label for="LaminaSG388">&nbsp; &nbsp;LOS GUSANOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG389" id="LaminaSG389" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;389 </td>                    
                                        <td> <label for="LaminaSG389">&nbsp; &nbsp;RAZAS DEL MUNDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG390" id="LaminaSG390" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;390 </td>                    
                                        <td> <label for="LaminaSG350">&nbsp; &nbsp;FIG. GEOMETRICAS PLANAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG391" id="LaminaSG391" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;391 </td>                    
                                        <td> <label for="LaminaSG391">&nbsp; &nbsp;CUERP.GEOM.CON VOLÚMEN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG392" id="LaminaSG392" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;392 </td>                    
                                        <td> <label for="LaminaSG392">&nbsp; &nbsp;LOS SEIS CONTINENTES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG393" id="LaminaSG393" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;393 </td>                    
                                        <td> <label for="LaminaSG393">&nbsp; &nbsp;EL ADN Y EL ARN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG394" id="LaminaSG394" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;394 </td>                    
                                        <td> <label for="LaminaSG394">&nbsp; &nbsp;DERECHOS DEL CONSUMIDOR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG395" id="LaminaSG395" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;395 </td>                    
                                        <td> <label for="LaminaSG395">&nbsp; &nbsp;LAS ARTICULACIONES</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG396" id="LaminaSG396" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;396 </td>                    
                                        <td> <label for="LaminaSG396">&nbsp; &nbsp;LA SANGRE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG397" id="LaminaSG397" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;397 </td>                    
                                        <td> <label for="LaminaSG397">&nbsp; &nbsp;SERVIDORES PÚBLICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG398" id="LaminaSG398" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;398 </td>                    
                                        <td> <label for="LaminaSG398">&nbsp; &nbsp;SERVICIOS PRIVADOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG399" id="LaminaSG399" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;399 </td>                    
                                        <td> <label for="LaminaSG399">&nbsp; &nbsp;BIOMAS ACUÁTICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG400" id="LaminaSG400" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;400 </td>                    
                                        <td> <label for="LaminaSG400">&nbsp; &nbsp;LOS VIAJES DE COLÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="S401" id="LaminaSG401" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;401 </td>                    
                                        <td> <label for="LaminaSG401">&nbsp; &nbsp;CANCIONES DE NAVIDAD N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG402" id="LaminaSG402" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;402 </td>                    
                                        <td> <label for="LaminaSG402">&nbsp; &nbsp;PRIMERA GUERRA MUNDIAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG403" id="LaminaSG403" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;403 </td>                    
                                        <td> <label for="LaminaSG403">&nbsp; &nbsp;SEGUNDA GUERRA MUNDIAL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG404" id="LaminaSG404" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;404 </td>                    
                                        <td> <label for="LaminaSG404">&nbsp; &nbsp;ABECEDARIO CURSIVO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG405" id="LaminaSG405" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;405 </td>                    
                                        <td> <label for="LaminaSG405">&nbsp; &nbsp;ABECEDARIO GÓTICO</label> </td>
                                    </tr>



                                </table>
                            </div>
                            <div class="col-sm-4" style="background-color: whitesmoke; padding-top: 3px;">           

                                <table class="textI">

                                    <tr>                                                              
                                        <td class="textC negrita" colspan="3"> &nbsp; &nbsp; TEMAS GENERALES </td>    
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG406" id="LaminaSG406" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;406 </td>                    
                                        <td> <label for="LaminaSG406">&nbsp; &nbsp;SUMA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG407" id="LaminaSG407" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;407 </td>                    
                                        <td> <label for="LaminaSG407">&nbsp; &nbsp;RESTA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG408" id="LaminaSG408" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;408 </td>                    
                                        <td> <label for="LaminaSG408">&nbsp; &nbsp;MULTIPLICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG409" id="LaminaSG409" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;409 </td>                    
                                        <td> <label for="LaminaSG409">&nbsp; &nbsp;DIVISIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG410" id="LaminaSG410" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;410 </td>                    
                                        <td> <label for="LaminaSG410">&nbsp; &nbsp;CLASIFICACIÓN SUSTANTIVO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG411" id="LaminaSG411" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;411 </td>                    
                                        <td> <label for="LaminaSG411">&nbsp; &nbsp;SUSTAN. GÉNERO NÚMERO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG412" id="LaminaSG412" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;412 </td>                    
                                        <td> <label for="LaminaSG412">&nbsp; &nbsp;ADJETIVO CLASIFICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG413" id="LaminaSG413" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;413 </td>                    
                                        <td> <label for="LaminaSG413">&nbsp; &nbsp;ADJETI. GÉNERO NÚMERO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG414" id="LaminaSG414" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;414 </td>                    
                                        <td> <label for="LaminaSG414">&nbsp; &nbsp;VERBO CLASIFICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG415" id="LaminaSG415" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;415 </td>                    
                                        <td> <label for="LaminaSG415">&nbsp; &nbsp;ARTÍCULO GÉNER. NÚMERO</label> </td>
                                    </tr>                                         
                                    <tr>
                                        <td> <input  type="number" name="SG416" id="LaminaSG416" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;416 </td>                    
                                        <td> <label for="LaminaSG416">&nbsp; &nbsp;PRONOMBRE CLASIFICACIÓN</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG417" id="LaminaSG417" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;417 </td>                    
                                        <td> <label for="LaminaSG417">&nbsp; &nbsp;DIPTONGO TRIPTONGO HIATO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG418" id="LaminaSG418" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;418 </td>                    
                                        <td> <label for="LaminaSG418">&nbsp; &nbsp;SINÓNIMOS Y ANTÓMICOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG419" id="LaminaSG419" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;419 </td>                    
                                        <td> <label for="LaminaSG419">&nbsp; &nbsp;CONJUNTOS N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG420" id="LaminaSG420" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;420 </td>                    
                                        <td> <label for="LaminaSG420">&nbsp; &nbsp;CONJUNTOS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG421" id="LaminaSG421" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;421 </td>                    
                                        <td> <label for="LaminaSG421">&nbsp; &nbsp;AGUDAS GRAVES ESDRÚJULAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG422" id="LaminaSG422" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;422 </td>                    
                                        <td> <label for="LaminaSG422">&nbsp; &nbsp;PLACAS TECTÓNICAS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG423" id="LaminaSG423" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;423 </td>                    
                                        <td> <label for="LaminaSG423">&nbsp; &nbsp;SÍLABAS COMPUESTAS BL BR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG424" id="LaminaSG424" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;424 </td>                    
                                        <td> <label for="LaminaSG424">&nbsp; &nbsp;SÍLABAS COMPUESTAS CL CR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG425" id="LaminaSG425" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;425 </td>                    
                                        <td> <label for="LaminaSG425">&nbsp; &nbsp;SÍLABAS COMPUESTAS FL FR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG426" id="LaminaSG426" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;426 </td>                    
                                        <td> <label for="LaminaSG426">&nbsp; &nbsp;SÍLABAS COMPUESTAS GL GR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG427" id="LaminaSG427" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;427 </td>                    
                                        <td> <label for="LaminaSG427">&nbsp; &nbsp;SÍLABAS COMPUESTAS PL PR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG428" id="LaminaSG428" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;428 </td>                    
                                        <td> <label for="LaminaSG428">&nbsp; &nbsp; SÍLABAS COMPUESTAS PL PR</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG42" id="LaminaSG429" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;429 </td>                    
                                        <td> <label for="LaminaSG429">&nbsp; &nbsp; EL DENGUE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG430" id="LaminaSG430" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;430 </td>                    
                                        <td> <label for="LaminaSG430">&nbsp; &nbsp; ACCIDENTES DE TRABAJO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG431" id="LaminaSG431" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp;&nbsp; 431 </td>                    
                                        <td> <label for="LaminaSG431">&nbsp; &nbsp;EL RELOJ</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG432" id="LaminaSG432" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;432 </td>                    
                                        <td> <label for="LaminaSG432">&nbsp; &nbsp; CULTURA SUMERIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG433" id="LaminaSG433" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;433 </td>                    
                                        <td> <label for="LaminaSG433">&nbsp; &nbsp; NÚMEROS ROMANOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG434" id="LaminaSG434" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;434 </td>                    
                                        <td> <label for="LaminaSG434">&nbsp; &nbsp; EL SONIDO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG435" id="LaminaSG435" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;435 </td>                    
                                        <td> <label for="LaminaSG435">&nbsp; &nbsp; EDUCAC.FÍSICA GIMNASIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG436" id="LaminaSG436" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;436 </td>                    
                                        <td> <label for="LaminaSG436">&nbsp; &nbsp; LA ESCULTURA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG437" id="LaminaSG437" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;437 </td>                    
                                        <td> <label for="LaminaSG437">&nbsp; &nbsp;CUERPOS GEOMÉTRICAS N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG438" id="LaminaSG438" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;438 </td>                    
                                        <td> <label for="LaminaSG438">&nbsp; &nbsp;CUERPOS GEOMÉTRICAS N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG439" id="LaminaSG439" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;439 </td>                    
                                        <td> <label for="LaminaSG439">&nbsp; &nbsp;CUERPOS GEOMÉTRICAS N°3</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG440" id="LaminaSG440" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;440 </td>                    
                                        <td> <label for="LaminaSG440">&nbsp; &nbsp;CUERPOS GEOMÉTRICAS N°4</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG441" id="LaminaSG441" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;441 </td>                    
                                        <td> <label for="LaminaSG441">&nbsp; &nbsp;CUERPOS GEOMÉTRICAS N°5</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG442" id="LaminaSG442" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;442 </td>                    
                                        <td> <label for="LaminaSG442">&nbsp; &nbsp;LA LETRA ¨RR¨</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG443" id="LaminaSG443" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;443 </td>                    
                                        <td> <label for="LaminaSG443">&nbsp; &nbsp;USOS DEL AGUA Y DEL AIRE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG444" id="LaminaSG444" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;444 </td>                    
                                        <td> <label for="LaminaSG444">&nbsp; &nbsp;ANTIVALORES N°1</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG445" id="LaminaSG445" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;445 </td>                    
                                        <td> <label for="LaminaSG445">&nbsp; &nbsp;ANTIVALORES N°2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG446" id="LaminaSG446" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;446 </td>                    
                                        <td> <label for="LaminaSG446">&nbsp; &nbsp;ÁRBOL GENIALÓGICO-FAMILIA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG447" id="LaminaSG447" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;447 </td>                    
                                        <td> <label for="LaminaSG447">&nbsp; &nbsp;CLASIF. RECICLAJE BASURA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG448" id="LaminaSG448" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;448 </td>                    
                                        <td> <label for="LaminaSG448">&nbsp; &nbsp;LA COMIDA CHATARRA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG449" id="LaminaSG449" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;449 </td>                    
                                        <td> <label for="LaminaSG449">&nbsp; &nbsp;NÚMEROS 1 Y 2</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG450" id="LaminaSG450" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;450 </td>                    
                                        <td> <label for="LaminaSG450">&nbsp; &nbsp;NÚMEROS 3 Y 4</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG451" id="LaminaSG451" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;451 </td>                    
                                        <td> <label for="LaminaSG451">&nbsp; &nbsp;NÚMEROS 5 Y 6</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG52" id="LaminaSG452" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;452 </td>                    
                                        <td> <label for="LaminaSG412">&nbsp; &nbsp;NÚMEROS 7 Y 8</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG453" id="LaminaSG453" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;453 </td>                    
                                        <td> <label for="LaminaSG453">&nbsp; &nbsp;NÚMEROS 9 Y 10</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG454" id="LaminaSG454" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;454 </td>                    
                                        <td> <label for="LaminaSG454">&nbsp; &nbsp;OBJETOS COLOR AMARILLO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG455" id="LaminaSG455" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;455 </td>                    
                                        <td> <label for="LaminaSG455">&nbsp; &nbsp;OBJETOS COLOR ROJO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG456" id="LaminaSG456" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;456 </td>                    
                                        <td> <label for="LaminaSG456">&nbsp; &nbsp;OBJETOS DE COLOR AZUL</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG457" id="LaminaSG457" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;457 </td>                    
                                        <td> <label for="LaminaSG457">&nbsp; &nbsp;OBJETOS DE COLOR MORADO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG458" id="LaminaSG458" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;458 </td>                    
                                        <td> <label for="LaminaSG458">&nbsp; &nbsp;OBJETOS DE COLOR VERDE</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG459" id="LaminaSG459" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;459 </td>                    
                                        <td> <label for="LaminaSG459">&nbsp; &nbsp;OBJET. DE COLOR NARANJA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG460" id="LaminaSG460" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;460 </td>                    
                                        <td> <label for="LaminaSG460">&nbsp; &nbsp;ARRIB. ABAJO-ABIERTO CERR.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG461" id="LaminaSG461" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;461 </td>                    
                                        <td> <label for="LaminaSG461">&nbsp; &nbsp;LLENO VACIO-GRANDE PEQ.</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG462" id="LaminaSG462" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;462 </td>                    
                                        <td> <label for="LaminaSG462">&nbsp; &nbsp;DERECH.IZQUI.-DEN.FUERA</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG463" id="LaminaSG463" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;463 </td>                    
                                        <td> <label for="LaminaSG463">&nbsp; &nbsp;CERCA LEJOS-ADELA. ATRÁS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG464" id="LaminaSG464" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;464 </td>                    
                                        <td> <label for="LaminaSG464">&nbsp; &nbsp;FRIO CALOR-PESA.LIVIANO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG465" id="LaminaSG465" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;465 </td>                    
                                        <td> <label for="LaminaSG465">&nbsp; &nbsp;LISO ÁSPERO-MUCHO POCO</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG466" id="LaminaSG466" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;466 </td>                    
                                        <td> <label for="LaminaSG466">&nbsp; &nbsp;LOS DESIERTOS</label> </td>
                                    </tr>
                                    <tr>
                                        <td> <input  type="number" name="SG467" id="LaminaSG467" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;467 </td>                    
                                        <td> <label for="LaminaSG467">&nbsp; &nbsp;CÁNCER DE MAMA</label> </td>
                                    </tr>                                          
                                    <tr>
                                        <td> <input  type="number" name="SG468" id="LaminaSG468" value="" min="25" max="9999" step="25" > </td>                    
                                        <td> &nbsp; &nbsp;468 </td>                    
                                        <td> <label for="LaminaSG468">&nbsp; &nbsp;CÁNCER DE PRÓSTATA</label> </td>
                                    </tr>






                                </table>
                            </div>







                        </div>

                    </div>







            </form>






        </div>
    </body>

</html>